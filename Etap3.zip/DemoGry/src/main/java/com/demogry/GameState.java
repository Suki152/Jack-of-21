package com.demogry;

/*
 Klasa przechowująca aktualny stan rozgrywki.
 DANE ULOTNE.
 */

public class GameState {
    private Deck deck; // Talia kart używana w tej rundzie
    private Player player1; // Gracz uno
    private Player player2; // Gracz dos
    private int currentBet = 1; // Aktualna stawka hp w rundzie o ktora graja gracze
    private Player currentTurn; // Kto ma aktualnie turę (cos zmienic z tym)

    public GameState(Player p1, Player p2) {
        this.deck = new Deck();
        this.player1 = p1;
        this.player2 = p2;
        this.currentTurn = p1;
    }

    public Deck getDeck() {
        return deck;
    }
    public Player getPlayer1() {
        return player1;
    }
    public Player getPlayer2() {
        return player2;
    }
    public int getCurrentBet() {
        return currentBet;
    }
    public void increaseBet() {
        currentBet++;
    }
}
