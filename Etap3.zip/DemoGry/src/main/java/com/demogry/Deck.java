package com.demogry;

import java.util.*;

/*
  Klasa reprezentująca talię kart.
  Przechowuje wszystkie dostępne karty w danej rundzie.
  Dane ulotne – resetują się po każdej nowej grze.
 */

public class Deck {
    private List<Card> cards = new ArrayList<>(); // Lista kart w talii

    public Deck() {
        // Tworzymy karty o wartościach 1–11 dla każdego koloru (♠, ♥, ♦, ♣)
        String[] suits = {"♠", "♥", "♦", "♣"};
        for (String suit : suits) {
            for (int i = 1; i <= 11; i++) {
                cards.add(new Card(i, suit));
            }
        }
        //Mieszanie tali aby karty były w losowej kolejnosci
        Collections.shuffle(cards);
    }

    //Dobiera karte/usuwa z tali/zwraca ja
    public Card draw() {
        return cards.remove(0);
    }
}
