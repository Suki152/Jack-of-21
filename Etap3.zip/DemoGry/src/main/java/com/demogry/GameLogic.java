package com.demogry;

/*
  Klasa odpowiedzialna za zasady gry i przebieg rund.
  Używa danych z GameState (ulotnych).
 */

public class GameLogic {
    private GameState state;

    public GameLogic(GameState state) {
        this.state = state;
    }

    // Odkrywanie kart, sprawdzenia podstawowe, aktualizacja pkt zycia

    public void endRound() {
        Player p1 = state.getPlayer1();
        Player p2 = state.getPlayer2();

        p1.revealHiddenCard();
        p2.revealHiddenCard();

        int s1 = p1.getTotalSum();
        int s2 = p2.getTotalSum();

        if (s1 > 21 && s2 > 21) return; // obaj przegrali/remis
        if (s1 == s2) return; // remis

        // Wybor zwyciezcy na podstawie wyniku (liczby pkt za karty)
        Player winner = (s1 <= 21 && (s1 > s2 || s2 > 21)) ? p1 : p2;
        Player loser = (winner == p1) ? p2 : p1;

        // Zmiany pkt zycia
        winner.changeHealth(state.getCurrentBet());
        loser.changeHealth(-state.getCurrentBet());

        // Zwiekszenie stawki
        state.increaseBet();
    }
}