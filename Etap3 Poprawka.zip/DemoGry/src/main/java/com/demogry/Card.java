package com.demogry;

/*
  Klasa reprezentująca pojedynczą kartę w talii.
  To część DANYCH ULOTNYCH – istnieje tylko w pamięci w trakcie gry.
 */

public class Card {
    private int value; // Wartość karty (np. 1–11)
    private String suit; // Kolor (♠, ♥, ♦, ♣)   SUBJECT TO CHANGE

    public Card(int value, String suit) {
        this.value = value;
        this.suit = suit;
    }

    public int getValue() { return value; }
    public String getSuit() { return suit; }
}