package com.demogry;

import java.io.*;
import java.util.*;

/*
  Zarządza zapisem i odczytem profili graczy z pliku.
  Odpowiada za DANE TRWAŁE – np. wyniki gier, liczba zwycięstw.
 */

public class ProfileManager {
    private static final String FILE_PATH = "profiles.txt";
    private static PlayerProfile currentProfile;

    /*
        Wczytuje profil z pliku lub tworzy nowy

     */
    public static PlayerProfile loadOrCreateProfile(String name) {
        Map<String, PlayerProfile> profiles = loadProfiles();
        return profiles.getOrDefault(name, new PlayerProfile(name));
    }

    /*
        Zapisuje profil do pliku //(dodaje nowe dane na koncu)//

     */
    public static void saveProfile(PlayerProfile profile) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH, true))) {
            writer.write(profile.getName() + ";" + profile.getGamesPlayed() + ";" + profile.getGamesWon());
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


//      Powinno wczytywac WSZYSTKIE profile z pliku do pamiecy za pomoca map ale nie rozumiem (naucze sie)
    private static Map<String, PlayerProfile> loadProfiles() {
        Map<String, PlayerProfile> map = new HashMap<>();
        File file = new File(FILE_PATH);
        if (!file.exists()) return map;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(";");
                PlayerProfile p = new PlayerProfile(parts[0]);
                map.put(parts[0], p);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return map;
    }
}