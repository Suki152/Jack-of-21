package com.demogry;

public class Main {
    public static void main(String[] args) {
        // Ładowanie profili graczy
        PlayerProfile profile1 = ProfileManager.loadOrCreateProfile("Kuba");
        PlayerProfile profile2 = ProfileManager.loadOrCreateProfile("Kacper");

        // Inicjalizacja gry
        Player player1 = new Player(profile1.getName());
        Player player2 = new Player(profile2.getName());
        GameState gameState = new GameState(player1, player2);
        GameLogic gameLogic = new GameLogic(gameState);

        // Rozdanie początkowych kart
        player1.drawInitialCards(gameState.getDeck());
        player2.drawInitialCards(gameState.getDeck());

        // Prosta symulacja rozgrywki
        System.out.println("=== POCZĄTEK GRY ===");
        printGameState(player1, player2);

        // Gracz 1 HIT
        System.out.println("\n" + player1.getName() + " dobiera kartę:");
        player1.hit(gameState.getDeck());
        printGameState(player1, player2);

        // Gracz 2 PASS
        System.out.println("\n" + player2.getName() + " pasuje");
        // Gracz 1 PASS
        System.out.println("\n" + player1.getName() + " pasuje");

        // Zakończenie rundy
        gameLogic.endRound();
        System.out.println("\n=== KONIEC RUNDY ===");
        printGameState(player1, player2);

        // Zapis statystyk
        profile1.incrementGamesPlayed();
        profile2.incrementGamesPlayed();

        if(player1.getHealth() > player2.getHealth()) {
            profile1.incrementGamesWon();
        } else if(player2.getHealth() > player1.getHealth()) {
            profile2.incrementGamesWon();
        }

        ProfileManager.saveProfile(profile1);
        ProfileManager.saveProfile(profile2);
    }

    // Peoste sprawdzenie zmiennych/statystyk itp
    private static void printGameState(Player p1, Player p2) {
        System.out.println(p1.getName() +
                " | Życie: " + p1.getHealth() +
                " | Widoczne karty: " + p1.getVisibleSum() +
                " | Ukryta karta: " + (p1.getTotalSum() - p1.getVisibleSum()));

        System.out.println(p2.getName() +
                " | Życie: " + p2.getHealth() +
                " | Widoczne karty: " + p2.getVisibleSum() +
                " | Ukryta karta: " + (p2.getTotalSum() - p2.getVisibleSum()));
    }
}
