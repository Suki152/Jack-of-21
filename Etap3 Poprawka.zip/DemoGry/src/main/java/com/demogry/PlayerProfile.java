package com.demogry;

/*
  Reprezentuje zapisany profil gracza.
  To przykład DANYCH TRWAŁYCH.
 */

public class PlayerProfile {
    private String name; // Nazwa gracza
    private int gamesPlayed; // Liczba rozegranych gier
    private int gamesWon; // Liczba wygranych gier

    public PlayerProfile(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
    public int getGamesPlayed() {
        return gamesPlayed;
    }
    public int getGamesWon() {
        return gamesWon;
    }

    // zwiekszenie licznika
    public void incrementGamesPlayed() {
        gamesPlayed++;
    }
    public void incrementGamesWon() {
        gamesWon++;
    }
}
