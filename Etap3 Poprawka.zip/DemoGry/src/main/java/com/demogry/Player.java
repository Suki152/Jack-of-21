package com.demogry;

import java.util.*;

/*
  Klasa opisująca stan pojedynczego gracza w trakcie gry.
  To również DANE ULOTNE – żyją tylko podczas trwania jednej rozgrywki.
 */

public class Player {
    private String name; // nick gracza
    private int health = 11; // Punkty zycia (startowo 11)
    private List<Card> hand = new ArrayList<>(); // Odkryte karty gracza
    private Card hiddenCard; // Ukryta karta (niewidoczna dla przeciwnika) Czyli ta pierwsza dobrana

    public Player(String name) {
        this.name = name;
    }

    // Dobiera poczatkowe 2 karty  SUBJECT TO CHANGE = pojedynczo
    public void drawInitialCards(Deck deck) {
        hiddenCard = deck.draw();
        hand.add(deck.draw());
    }

    // Dobranie karty w sposb widoczny podczas tury
    public void hit(Deck deck) {
        hand.add(deck.draw());
    }

    // Suma widocznych kart (dla oponenta)
    public int getVisibleSum() {
        return hand.stream().mapToInt(Card::getValue).sum();
    }

    // Suma karta dla gracza
    public int getTotalSum() {
        return getVisibleSum() + (hiddenCard != null ? hiddenCard.getValue() : 0);
    }

    // Ujawnienie ukrytej karty po zakonczeniu rundy (czyli gracz i jego wróg nacisneli PASS)
    public void revealHiddenCard() {
        if (hiddenCard != null) {
            hand.add(hiddenCard);
            hiddenCard = null;
        }
    }

    public int getHealth() {
        return health;
    }
    public void changeHealth(int amount) {
        health += amount;
    }
    public String getName() {
        return name;
    }
}
