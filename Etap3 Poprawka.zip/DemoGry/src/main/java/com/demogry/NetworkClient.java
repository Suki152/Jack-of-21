package com.demogry;

public class NetworkClient {

    // Trzeba będzie coś wymyslec żeby połączenie było :<<

}
