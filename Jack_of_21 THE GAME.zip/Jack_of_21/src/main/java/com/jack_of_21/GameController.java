package com.jack_of_21;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.effect.DropShadow;
import javafx.scene.paint.Color;
import javafx.animation.PauseTransition;
import javafx.util.Duration;
import javafx.scene.control.Alert;
import javafx.scene.text.TextAlignment;
import javafx.geometry.Pos;
import java.util.ArrayList;
import java.util.List;

/**
 * Kontroler widoku gry (JavaFX).
 * Zarządza interfejsem użytkownika, obsługuje interakcje gracza,
 * komunikację sieciową (jako Listener) oraz wizualizację stanu gry.
 * Łączy warstwę prezentacji z logiką biznesową (GameLogic).
 *
 * @author Jakub Bąk
 * @author Kacper Chojnacki
 */
public class GameController implements NetworkManager.PacketListener {

    // --- Elementy interfejsu zdefiniowane w pliku FXML ---
    @FXML private Label playerScoreLabel;
    @FXML private Label opponentScoreLabel;
    @FXML private HBox playerCardsContainer;
    @FXML private HBox opponentCardsContainer;
    @FXML private Button hitButton;
    @FXML private Button standButton;
    @FXML private Button nextRoundButton;
    @FXML private Label betValueLabel;
    @FXML private Label playerHPValueLabel;
    @FXML private Label opponentHPValueLabel;
    @FXML private Label playerNameLabel;
    @FXML private Label opponentNameLabel;
    @FXML private Label turnLabel;
    @FXML private HBox specialCardsContainer;

    /** Instancja logiki gry. */
    private GameLogic game = new GameLogic();
    /** Menedżer sieci do obsługi połączeń multiplayer. */
    private NetworkManager networkManager;
    /** Flaga określająca czy gra toczy się w trybie wieloosobowym. */
    private boolean isMultiplayer = false;
    /** Flaga zapobiegająca wielokrotnemu odtwarzaniu dźwięku końca rundy. */
    private boolean roundSoundPlayed = false;

    // Listy widoków kart (nieużywane aktywnie w logice, ale przydatne do referencji)
    private List<ImageView> playerCardViews = new ArrayList<>();
    private List<ImageView> opponentCardViews = new ArrayList<>();

    /** Flaga oznaczająca, czy statystyki po grze zostały już zapisane. */
    private boolean statsRecorded = false;

    // Zmienne do przechowywania nazw w trybie multi
    private String myNickName = "GRACZ";
    private String opponentNickName = "PRZECIWNIK";

    // Efekty wizualne dla interfejsu
    private DropShadow activePlayerEffect;
    private DropShadow roundWinnerEffect;
    private DropShadow gameWinnerEffect;
    private DropShadow tieEffect;

    /**
     * Metoda inicjalizująca kontroler po załadowaniu pliku FXML.
     * Konfiguruje efekty, sprawdza połączenie sieciowe, ustawia muzykę
     * i przygotowuje grę (Single lub Multiplayer).
     */
    @FXML
    private void initialize() {
        initializeEffects();

        turnLabel.setTextAlignment(TextAlignment.CENTER);
        turnLabel.setAlignment(javafx.geometry.Pos.CENTER);
        turnLabel.setMaxWidth(Double.MAX_VALUE);

        networkManager = NetworkManager.getInstance();
        SoundManager.getInstance().playBackgroundMusic(SoundManager.MusicType.GAME);
        isMultiplayer = networkManager.isConnected();

        if (ProfileManager.getCurrentProfile() != null) {
            myNickName = ProfileManager.getCurrentProfile().getName();
        }

        if (isMultiplayer) {
            setupMultiplayer();
        } else {
            setupSinglePlayer();
        }
        roundSoundPlayed = false;
        updateUI();
    }

    // --- SETUP ---

    /**
     * Konfiguruje grę dla trybu wieloosobowego.
     * Rejestruje listener sieciowy, wysyła handshake i ustala role (Host/Client).
     */
    private void setupMultiplayer() {
        networkManager.setPacketListener(this);

        // 1. Wyślij swoje imię (HANDSHAKE) - wysyłane tylko raz!
        networkManager.sendHandshake(myNickName);

        if (networkManager.isHost()) {
            game.setHostName(myNickName);
            game.setClientName("Oczekiwanie...");
            game.setPlayerTurn(true);
            // Host wysyła początkowy stan gry
            sendGameState();
        } else {
            game.setClientName(myNickName);
            game.setHostName("Host"); // Tymczasowo
            game.setPlayerTurn(false);
        }
    }

    /**
     * Konfiguruje grę dla trybu jednoosobowego (przeciwko AI).
     */
    private void setupSinglePlayer() {
        game.setHostName(myNickName);
        game.setClientName("KOMPUTER");
    }

    // --- OBSŁUGA SIECI (PacketListener) ---

    /**
     * Wywoływana po otrzymaniu pakietu HANDSHAKE z imieniem przeciwnika.
     * Aktualizuje nazwy w grze i odświeża interfejs.
     *
     * @param name Imię otrzymane od drugiego gracza.
     */
    @Override
    public void onHandshakeReceived(String name) {
        // Otrzymano imię przeciwnika - zapisz je i odśwież UI
        this.opponentNickName = name;
        if (networkManager.isHost()) {
            game.setClientName(name);
            // Host odsyła stan, żeby klient też zobaczył aktualne imiona
            sendGameState();
        } else {
            game.setHostName(name);
        }
        updateUI();
    }

    /**
     * Wywoływana po otrzymaniu pakietu ACTION (np. HIT, STAND, SPECIAL).
     * Obsługuje odtwarzanie dźwięków oraz logikę gry (jeśli jest się Hostem).
     *
     * @param action Kod akcji (np. "HIT", "STAND", "SPECIAL:SAW").
     */
    @Override
    public void onActionReceived(String action) {
        javafx.application.Platform.runLater(() -> {

            // 1. SWITCH - Obsługuje dźwięki (DLA WSZYSTKICH) i logikę (DLA HOSTA)
            switch (action) {
                case "HIT":
                    // Dźwięk gra dla każdego (Host i Klient)
                    SoundManager.getInstance().playSound(SoundManager.SoundEffect.HIT);

                    // Logika tylko dla Hosta (bo tylko Host ma talię kart)
                    if (networkManager.isHost()) {
                        game.opponentHit();
                    }
                    break;

                case "STAND":
                    SoundManager.getInstance().playSound(SoundManager.SoundEffect.STAND);

                    if (networkManager.isHost()) {
                        game.opponentStand();
                    }
                    break;

                case "NEXT_ROUND":
                    SoundManager.getInstance().playSound(SoundManager.SoundEffect.CLICK);

                    if (networkManager.isHost()) {
                        game.startNewRound();
                    } else {
                        game.startNewRound();
                    }
                    break;

                default:
                    if (action.startsWith("SPECIAL:")) {
                        try {
                            String typeName = action.split(":")[1];
                            SpecialCardType type = SpecialCardType.valueOf(typeName);

                            // Dźwięki specjalne
                            SoundManager.getInstance().playSound(SoundManager.SoundEffect.CLICK);

                            if (networkManager.isHost()) {
                                game.useSpecialCard(type, false);
                            }
                        } catch (Exception e) {
                        }
                    }
                    break;
            }

            // 2. SYNCHRONIZACJA - Tylko Host wysyła nowy stan po zmianach
            if (networkManager.isHost()) {
                sendGameState();
                updateUI();
            } else {
                // Klient tylko odświeża UI (czeka na pakiet z kartami)
                updateUI();
            }
        });
    }

    /**
     * Wywoływana po otrzymaniu pakietu STATE z pełnym stanem gry.
     * Służy Klientowi do synchronizacji swojego widoku z Hostem.
     *
     * @param state Otrzymany obiekt GameState.
     */
    @Override
    public void onGameStateReceived(GameState state) {
        // Tylko KLIENT odbiera pełny stan (Host ma "prawdę" u siebie)
        if (!networkManager.isHost()) {
            applyGameStateForClient(state);
        }
    }

    /**
     * Obsługuje utratę połączenia sieciowego.
     */
    @Override
    public void onConnectionLost() {
        showAlert("Błąd połączenia", "Utracono połączenie z przeciwnikiem");
        networkManager.disconnect();
        SceneUtils.changeScene("menu.fxml");
    }

    @Override
    public void onPlayerConnected() { }

    // --- LOGIKA DOSTOSOWANIA STANU DLA KLIENTA ---

    /**
     * Dostosowuje otrzymany stan gry (perspektywa Hosta) do perspektywy Klienta.
     * Odwraca ręce graczy, punkty HP, flagi tury i zwycięzców, aby Klient widział
     * siebie jako "Playera", a Hosta jako "Opponenta".
     *
     * @param state Stan gry otrzymany od Hosta.
     * @author Jakub Bąk
     * @author Kacper Chojnacki
     */
    private void applyGameStateForClient(GameState state) {
        // Klient musi "odwrócić" stan gry (widzieć siebie jako Player, a Hosta jako Opponent)
        List<Integer> tempHand = new ArrayList<>(state.getPlayerHand());
        state.setPlayerHand(new ArrayList<>(state.getOpponentHand()));
        state.setOpponentHand(new ArrayList<>(tempHand));

        List<String> tempSpecial = new ArrayList<>(state.getPlayerSpecialHand());
        state.setPlayerSpecialHand(new ArrayList<>(state.getOpponentSpecialHand()));
        state.setOpponentSpecialHand(new ArrayList<>(tempSpecial));

        boolean tempStand = state.isPlayerStand();
        state.setPlayerStand(state.isOpponentStand());
        state.setOpponentStand(tempStand);

        state.setPlayerTurn(!state.isPlayerTurn());

        int tempHP = state.getPlayerHP();
        state.setPlayerHP(state.getOpponentHP());
        state.setOpponentHP(tempHP);

        // Zamiana zwycięzców
        String rWinner = state.getRoundWinner();
        if ("PLAYER".equals(rWinner)) state.setRoundWinner("OPPONENT");
        else if ("OPPONENT".equals(rWinner)) state.setRoundWinner("PLAYER");

        String gWinner = state.getGameWinner();
        if ("PLAYER".equals(gWinner)) state.setGameWinner("OPPONENT");
        else if ("OPPONENT".equals(gWinner)) state.setGameWinner("PLAYER");

        // Aplikuj stan do logiki lokalnej
        game.applyGameState(state);

        // Przywróć poprawne nazwy w UI
        game.setHostName(opponentNickName); // Host to nasz przeciwnik
        game.setClientName(myNickName);     // My to Klient

        updateUI();
    }

    // --- WYSYŁANIE (Host -> Stan, Klient -> Akcja) ---

    /**
     * Wysyła aktualny stan gry do Klienta (używane tylko przez Hosta).
     */
    private void sendGameState() {
        if (!isMultiplayer || !networkManager.isHost()) return;
        GameState state = game.createGameState();
        networkManager.sendGameState(state);
    }

    /**
     * Wysyła kod akcji do Hosta (używane tylko przez Klienta).
     * @param actionCode Kod akcji (np. "HIT").
     */
    private void sendAction(String actionCode) {
        if (!isMultiplayer) return;
        // Klient wysyła tylko krótki kod
        networkManager.sendAction(actionCode);
    }

    // --- INTERAKCJE UŻYTKOWNIKA ---

    /**
     * Obsługa przycisku "Dobierz" (Hit).
     * Wysyła akcję do sieci (Multi) lub wykonuje ruch lokalnie i wyzwala AI (Single).
     */
    @FXML
    private void onHit() {
        SoundManager.getInstance().playSound(SoundManager.SoundEffect.HIT);
        if (canPlay()) {
            if (isMultiplayer) {
                if (networkManager.isHost()) {
                    game.playerHit();
                    sendGameState();
                } else {
                    // Klient wysyła tylko prośbę
                    sendAction("HIT");
                }
            } else {
                game.playerHit();
                checkAI();
            }
            updateUI();
        }
    }

    /**
     * Obsługa przycisku "Pasuj" (Stand).
     * Blokuje ruch gracza i przekazuje turę przeciwnikowi.
     */
    @FXML
    private void onStand() {
        SoundManager.getInstance().playSound(SoundManager.SoundEffect.STAND);
        if (canPlay()) {
            if (isMultiplayer) {
                if (networkManager.isHost()) {
                    game.playerStand();
                    sendGameState();
                } else {
                    sendAction("STAND");
                }
            } else {
                game.playerStand();
                checkAI();
            }
            updateUI();
        }
    }

    /**
     * Obsługa przycisku "Następna Runda".
     * Dostępna tylko po zakończeniu rundy. W trybie multi zarządza nią Host.
     */
    @FXML
    private void onNextRound() {
        if (game.isRoundEnded() && !game.isGameEnded()) {
            if (isMultiplayer) {
                if (networkManager.isHost()) {
                    game.startNextRound();
                    sendGameState();
                }
            } else {
                game.startNextRound();
            }
            roundSoundPlayed = false;
            updateUI();
        }
    }

    private void onSpecialCardUse(SpecialCardType type) {
    }

    // --- AKTUALIZACJA KART SPECJALNYCH ---

    /**
     * Odświeża panel kart specjalnych.
     * Generuje przyciski dla każdej posiadanej karty specjalnej i podpina zdarzenia kliknięcia.
     *
     * @author Jakub Bąk
     * @author Kacper Chojnacki
     */
    private void updateSpecialCardsUI() {
        specialCardsContainer.getChildren().clear();
        for (SpecialCardType card : game.getPlayerSpecialCards()) {
            Button cardBtn = new Button();
            ImageView icon = getSpecialCardImage(card);
            if (icon != null) {
                cardBtn.setGraphic(icon);
                cardBtn.setStyle("-fx-background-color: transparent; -fx-cursor: hand;");
            } else {
                cardBtn.setText(card.name());
            }

            cardBtn.setOnAction(e -> {
                if (!canPlay()) return;

                if (isMultiplayer) {
                    if (networkManager.isHost()) {
                        game.useSpecialCard(card, true);
                        sendGameState();
                    } else {
                        sendAction("SPECIAL:" + card.name());
                        game.useSpecialCard(card, true);
                    }
                } else {
                    game.useSpecialCard(card, true);
                }
                updateUI();
            });
            specialCardsContainer.getChildren().add(cardBtn);
        }
    }

    // --- POZOSTAŁE METODY POMOCNICZE (Bez zmian logicznych) ---

    /**
     * Sprawdza, czy gracz może wykonać ruch (czy jest jego tura, runda trwa i nie spasował).
     */
    private boolean canPlay() {
        return game.isPlayerTurn() && !game.isRoundEnded() && !game.isPlayerStand();
    }

    /**
     * Sprawdza i inicjuje turę AI w trybie dla jednego gracza.
     */
    private void checkAI() {
        if (!game.isPlayerTurn() && !game.isRoundEnded()) {
            startAITurn();
        }
    }

    /**
     * Obsługa przycisku wyjścia do menu.
     * Rozłącza sieć i zmienia scenę.
     */
    @FXML
    private void onBack() {
        networkManager.disconnect();
        SceneUtils.changeScene("menu.fxml");
    }

    /**
     * Symuluje turę przeciwnika komputerowego z opóźnieniem (dla efektu wizualnego).
     */
    private void startAITurn() {
        updateUI();
        PauseTransition pause = new PauseTransition(Duration.seconds(1));
        pause.setOnFinished(e -> {
            // makeAIMove zwraca true jeśli AI dobrało (HIT), false jeśli spasowało (STAND)
            boolean aiHit = game.makeAIMove();

            updateUI();

            if (aiHit) {
                // AI dobrało kartę -> Dźwięk HIT
                SoundManager.getInstance().playSound(SoundManager.SoundEffect.HIT);

                if (!game.isRoundEnded() && !game.isPlayerTurn()) {
                    startAITurn();
                }
            } else {
                // AI spasowało (nie dobrało karty) -> Dźwięk STAND
                SoundManager.getInstance().playSound(SoundManager.SoundEffect.STAND);
            }
        });
        pause.play();
    }

    /**
     * Główna metoda aktualizująca stan interfejsu użytkownika.
     * Odświeża teksty, wyniki, widoczność przycisków, karty i efekty wizualne.
     *
     * @author Jakub Bąk
     * @author Kacper Chojnacki
     */
    private void updateUI() {
        // Aktualizacja nazw
        if (isMultiplayer) {
            // W UI używamy zapamiętanych nazw
            if (networkManager.isHost()) {
                playerNameLabel.setText(myNickName);
                opponentNameLabel.setText(opponentNickName);
            } else {
                playerNameLabel.setText(myNickName);
                opponentNameLabel.setText(opponentNickName);
            }
        } else {
            playerNameLabel.setText(game.getHostName());
            opponentNameLabel.setText(game.getClientName());
        }

        if (game.isRoundEnded()) {
            playerScoreLabel.setText(playerNameLabel.getText() + ": " + game.getPlayerFullScore());
            opponentScoreLabel.setText(opponentNameLabel.getText() + ": " + game.getOpponentFullScore());

            if (!roundSoundPlayed) {
                if (game.getRoundWinner() == GameLogic.Winner.PLAYER) {
                    SoundManager.getInstance().playSound(SoundManager.SoundEffect.WIN_SFX);
                } else if (game.getRoundWinner() == GameLogic.Winner.OPPONENT) {
                    SoundManager.getInstance().playSound(SoundManager.SoundEffect.LOSS_SFX);
                }

                roundSoundPlayed = true; // Zabezpieczenie przed ponownym odtworzeniem
            }

        } else {
            playerScoreLabel.setText(playerNameLabel.getText() + ": " + game.getPlayerFullScore());
            opponentScoreLabel.setText(opponentNameLabel.getText() + ": ? + " + game.getOpponentVisibleScore());
        }

        betValueLabel.setText(String.valueOf(game.getCurrentBet()));
        playerHPValueLabel.setText(String.valueOf(game.getPlayerHP()));
        opponentHPValueLabel.setText(String.valueOf(game.getOpponentHP()));

        if (game.isRoundEnded()) {
            String winnerText;
            GameLogic.Winner rw = game.getRoundWinner();

            if (rw == GameLogic.Winner.TIE) {
                winnerText = "REMIS!";
            } else if (rw == GameLogic.Winner.PLAYER) {
                winnerText = "WYGRAŁ: " + playerNameLabel.getText();
            } else {
                winnerText = "WYGRAŁ: " + opponentNameLabel.getText();
            }
            turnLabel.setText("RUNDA ZAKOŃCZONA\n" + winnerText);

        } else if (game.isPlayerTurn()) {
            turnLabel.setText("TURA: " + playerNameLabel.getText());
        } else {
            turnLabel.setText("TURA: " + opponentNameLabel.getText());
        }

        boolean playerCanPlay = canPlay();
        boolean roundEnded = game.isRoundEnded();
        boolean deckEmpty = game.getDeck().isEmpty();

        hitButton.setDisable(!playerCanPlay);
        standButton.setDisable(!playerCanPlay);

        if (isMultiplayer) {
            nextRoundButton.setDisable(!roundEnded || game.isGameEnded() || !networkManager.isHost());
        } else {
            nextRoundButton.setDisable(!roundEnded || game.isGameEnded());
        }

        updateCardsDisplay();
        updateSpecialCardsUI();
        updatePlayerHighlights();

        if (game.isGameEnded()) {
            String winnerName = game.getPlayerHP() > 0 ? playerNameLabel.getText() : opponentNameLabel.getText();
            turnLabel.setText("KONIEC GRY! WYGRAŁ: " + winnerName);
            nextRoundButton.setDisable(true);

            if (!statsRecorded) {
                statsRecorded = true;
                handleGameOver();
            }
        }
    }

    /**
     * Inicjalizuje efekty DropShadow używane do podświetlania aktywnego gracza i zwycięzcy.
     */
    private void initializeEffects() {
        activePlayerEffect = new DropShadow(); activePlayerEffect.setColor(Color.GOLD); activePlayerEffect.setRadius(30); activePlayerEffect.setSpread(0.3);
        roundWinnerEffect = new DropShadow(); roundWinnerEffect.setColor(Color.GREEN); roundWinnerEffect.setRadius(30); roundWinnerEffect.setSpread(0.3);
        gameWinnerEffect = new DropShadow(); gameWinnerEffect.setColor(Color.PURPLE); gameWinnerEffect.setRadius(30); gameWinnerEffect.setSpread(0.3);
        tieEffect = new DropShadow(); tieEffect.setColor(Color.WHITE); tieEffect.setRadius(30); tieEffect.setSpread(0.3);
    }

    /**
     * Aktualizuje efekty wizualne (podświetlenia) wokół kart i nazw graczy
     * w zależności od stanu gry (tura, zwycięstwo rundy/gry).
     */
    private void updatePlayerHighlights() {
        playerCardsContainer.setEffect(null); opponentCardsContainer.setEffect(null);
        playerNameLabel.setEffect(null); opponentNameLabel.setEffect(null);

        if (game.isGameEnded()) {
            GameLogic.Winner gw = game.getGameWinner();
            if (gw == GameLogic.Winner.PLAYER) { playerCardsContainer.setEffect(gameWinnerEffect); playerNameLabel.setEffect(gameWinnerEffect); }
            else if (gw == GameLogic.Winner.OPPONENT) { opponentCardsContainer.setEffect(gameWinnerEffect); opponentNameLabel.setEffect(gameWinnerEffect); }
            else if (gw == GameLogic.Winner.TIE) { playerCardsContainer.setEffect(tieEffect); opponentCardsContainer.setEffect(tieEffect); }
        } else if (game.isRoundEnded()) {
            GameLogic.Winner rw = game.getRoundWinner();
            if (rw == GameLogic.Winner.PLAYER) { playerCardsContainer.setEffect(roundWinnerEffect); playerNameLabel.setEffect(roundWinnerEffect); }
            else if (rw == GameLogic.Winner.OPPONENT) { opponentCardsContainer.setEffect(roundWinnerEffect); opponentNameLabel.setEffect(roundWinnerEffect); }
            else if (rw == GameLogic.Winner.TIE) { playerCardsContainer.setEffect(tieEffect); opponentCardsContainer.setEffect(tieEffect); playerNameLabel.setEffect(tieEffect); opponentNameLabel.setEffect(tieEffect);}
        } else {
            if (game.isPlayerTurn()) { playerCardsContainer.setEffect(activePlayerEffect); playerNameLabel.setEffect(activePlayerEffect); }
            else { opponentCardsContainer.setEffect(activePlayerEffect); opponentNameLabel.setEffect(activePlayerEffect); }
        }
    }

    /**
     * Czyści i generuje na nowo widoki kart w kontenerach gracza i przeciwnika.
     * Obsługuje ukrywanie pierwszej karty przeciwnika w trakcie rundy.
     */
    private void updateCardsDisplay() {
        playerCardsContainer.getChildren().clear();
        opponentCardsContainer.getChildren().clear();

        for (Card card : game.getPlayer().getHand()) {
            playerCardsContainer.getChildren().add(createCardView(card.getValue(), false));
        }

        List<Card> opponentHand = game.getOpponent().getHand();
        for (int i = 0; i < opponentHand.size(); i++) {
            boolean showFace = (i > 0) || game.isRoundEnded();
            opponentCardsContainer.getChildren().add(createCardView(opponentHand.get(i).getValue(), !showFace));
        }
    }

    /**
     * Tworzy obiekt ImageView dla pojedynczej karty.
     * W razie braku pliku graficznego generuje kartę procedurally.
     *
     * @param cardValue Wartość karty.
     * @param isHidden Czy karta ma być odwrócona (zakryta).
     * @return Węzeł JavaFX reprezentujący kartę.
     */
    private javafx.scene.Node createCardView(int cardValue, boolean isHidden) {
        try {
            String imagePath = isHidden ? SkinManager.getInstance().getCardBackPath() : SkinManager.getInstance().getCardPath(cardValue);
            java.io.InputStream is = getClass().getResourceAsStream(imagePath);

            if (is == null) {
                System.err.println("Brak pliku graficznego: " + imagePath + " -> Używam karty domyślnej.");
                return createProceduralCard(cardValue, isHidden);
            }

            ImageView imageView = new ImageView(new Image(is));
            imageView.setFitWidth(80);
            imageView.setFitHeight(112);
            imageView.setPreserveRatio(true);
            imageView.setEffect(new DropShadow(10, Color.BLACK));
            return imageView;

        } catch (Exception e) {
            return createProceduralCard(cardValue, isHidden);
        }
    }

    /**
     * Awaryjne tworzenie wyglądu karty za pomocą kształtów JavaFX, gdy brak grafiki.
     */
    private javafx.scene.Node createProceduralCard(int value, boolean isHidden) {
        javafx.scene.layout.StackPane card = new javafx.scene.layout.StackPane();
        card.setPrefSize(80, 112);

        javafx.scene.shape.Rectangle bg = new javafx.scene.shape.Rectangle(80, 112);
        bg.setArcWidth(10);
        bg.setArcHeight(10);
        bg.setStroke(Color.BLACK);
        bg.setStrokeWidth(2);

        card.setEffect(new DropShadow(5, Color.BLACK));

        if (isHidden) {
            bg.setFill(Color.DARKRED);
            javafx.scene.shape.Rectangle border = new javafx.scene.shape.Rectangle(60, 92);
            border.setFill(Color.TRANSPARENT);
            border.setStroke(Color.GOLD);
            border.setStrokeWidth(2);
            card.getChildren().addAll(bg, border);
        } else {
            bg.setFill(Color.WHITE);
            Label valueLabel = new Label(String.valueOf(value));
            valueLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: black;");

            if (value >= 10) valueLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: darkblue;");

            card.getChildren().addAll(bg, valueLabel);
        }

        return card;
    }

    /**
     * Pobiera obrazek dla danej karty specjalnej.
     * @param type Typ karty specjalnej.
     * @return ImageView z grafiką karty.
     */
    private ImageView getSpecialCardImage(SpecialCardType type) {
        try {
            String path = "/com/jack_of_21/images/cards/" + type.name() + ".png";
            ImageView view = new ImageView(new Image(getClass().getResourceAsStream(path)));
            view.setFitWidth(50); view.setFitHeight(70); view.setPreserveRatio(true);
            return view;
        } catch (Exception e) { return null; }
    }


    /**
     * Obsługuje koniec gry (Game Over).
     * Odtwarza muzykę zwycięstwa/porażki i aktualizuje statystyki profilu.
     */
    private void handleGameOver() {
        boolean playerWon = (game.getGameWinner() == GameLogic.Winner.PLAYER);

        if (playerWon) {
            SoundManager.getInstance().playBackgroundMusic(SoundManager.MusicType.WIN);
        } else {
            SoundManager.getInstance().playBackgroundMusic(SoundManager.MusicType.LOSS);
        }
            if (playerWon) {
                ProfileManager.getCurrentProfile().incrementGamesWon();
            }
            ProfileManager.getCurrentProfile().incrementGamesPlayed();
            ProfileManager.saveCurrentProfile();
    }

    /**
     * Wyświetla proste okno dialogowe z informacją.
     * @param title Tytuł okna.
     * @param message Treść wiadomości.
     */
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title); alert.setHeaderText(null); alert.setContentText(message);
        alert.showAndWait();
    }

    /**
     * Obsługa powrotu do menu głównego.
     * Zatrzymuje muzykę, rozłącza sieć i zmienia widok.
     */
    @FXML
    private void onMenu() {
        SoundManager.getInstance().playSound(SoundManager.SoundEffect.CLICK);
        SoundManager.getInstance().stopMusic();
        SoundManager.getInstance().playBackgroundMusic(SoundManager.MusicType.MENU);

        if (NetworkManager.getInstance() != null) {
            NetworkManager.getInstance().disconnect();
        }

        SceneUtils.changeScene("menu.fxml");
    }
}