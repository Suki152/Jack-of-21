package com.jack_of_21;

import java.util.ArrayList;
import java.util.List;

/**
 * Klasa reprezentująca uczestnika rozgrywki (gracza lub przeciwnika).
 * Przechowuje aktualną rękę kart oraz udostępnia metody do zarządzania nią
 * i obliczania aktualnego wyniku punktowego.
 *
 * @author Jakub Bąk
 * @author Kacper Chojnacki
 */
public class Player {
    /** Lista kart trzymanych w ręce przez gracza. */
    private List<Card> hand = new ArrayList<>();

    /**
     * Dodaje kartę do ręki gracza.
     * @param card Obiekt karty do dodania.
     */
    public void addCard(Card card) {
        hand.add(card);
    }

    /**
     * Oblicza sumę punktów wszystkich kart w ręce.
     * Wykorzystuje strumienie do zsumowania wartości kart.
     *
     * @return Sumaryczna wartość punktowa ręki.
     */
    public int getScore() {
        return hand.stream().mapToInt(Card::getValue).sum();
    }

    /**
     * Zwraca listę kart posiadanych przez gracza.
     * @return Lista obiektów Card.
     */
    public List<Card> getHand() {
        return hand;
    }

    /**
     * Usuwa wszystkie karty z ręki gracza.
     * Używane przy restarcie rundy.
     */
    public void clearHand() {
        hand.clear();
    }
}