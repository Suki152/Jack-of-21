package com.jack_of_21;

/**
 * Typ wyliczeniowy definiujący dostępne karty specjalne w grze.
 * Każda wartość przechowuje krótki opis działania karty,
 * który może być wyświetlany w interfejsie użytkownika.
 *
 * @author Jakub Bąk
 * @author Kacper Chojnacki
 */
public enum SpecialCardType {
    /** Zwiększa stawkę zakładu (obrażenia) o 1. */
    BET_UP("Zwiększ Stawkę (+1)"),
    /** Zmniejsza stawkę zakładu (obrażenia) o 1, do minimum 1. */
    BET_DOWN("Zmniejsz Stawkę (-1)"),
    /** Zwraca ostatnią kartę gracza do talii. */
    RETURN_OWN("Cofnij swoją kartę"),
    /** Zwraca ostatnią kartę przeciwnika do talii. */
    RETURN_OPP("Cofnij kartę wroga"),

    /** Przecina wartość ostatniej karty na pół (zaokrąglając w górę). */
    SAW("Przecina ostatnio dobraną kartę na pół"),
    /** Zamienia ostatnie karty gracza i przeciwnika miejscami. */
    MIRROR("Lustro: Zamień swoją ostatnią kartę z kartą wroga"),
    /** Zmienia wartość ostatniej karty na 7. */
    LCK7("Szczęśliwa 7: Zamień ostatnią kartę na 7");

    /** Opis tekstowy działania karty. */
    private final String description;

    /**
     * Konstruktor typu wyliczeniowego.
     * @param description Tekstowy opis karty.
     */
    SpecialCardType(String description) {
        this.description = description;
    }

    /**
     * Pobiera opis działania karty.
     * @return String z opisem.
     */
    public String getDescription() {
        return description;
    }
}