package com.jack_of_21;

/**
 * Klasa modelu danych reprezentująca profil gracza.
 * Przechowuje statystyki takie jak nazwa, liczba rozegranych gier
 * oraz liczba zwycięstw. Służy do zapisu postępów i wyświetlania ich w menu.
 *
 * @author Jakub Bąk
 * @author Kacper Chojnacki
 */
public class PlayerProfile {
    /** Nazwa (nick) gracza. */
    private String name;
    /** Liczba rozegranych meczy. */
    private int gamesPlayed;
    /** Liczba wygranych meczy. */
    private int gamesWon;

    /**
     * Konstruktor tworzący nowy profil lub odtwarzający go z danych.
     *
     * @param name        Nazwa gracza.
     * @param gamesPlayed Liczba rozegranych gier.
     * @param gamesWon    Liczba wygranych gier.
     */
    public PlayerProfile(String name, int gamesPlayed, int gamesWon) {
        this.name = name;
        this.gamesPlayed = gamesPlayed;
        this.gamesWon = gamesWon;
    }

    /**
     * Pobiera nazwę gracza.
     * @return String z nazwą.
     */
    public String getName() {
        return name;
    }

    /**
     * Pobiera liczbę rozegranych gier.
     * @return Liczba meczy.
     */
    public int getGamesPlayed() {
        return gamesPlayed;
    }

    /**
     * Pobiera liczbę wygranych gier.
     * @return Liczba zwycięstw.
     */
    public int getGamesWon() {
        return gamesWon;
    }

    /**
     * Inkrementuje licznik rozegranych gier o 1.
     */
    public void incrementGamesPlayed() {
        gamesPlayed++;
    }

    /**
     * Inkrementuje licznik wygranych gier o 1.
     */
    public void incrementGamesWon() {
        gamesWon++;
    }

    /**
     * Oblicza procentowy wskaźnik zwycięstw (Win Rate).
     * Zabezpieczona przed dzieleniem przez zero.
     *
     * @return String sformatowany jako procent (np. "50%").
     */
    public String getWinRate() {
        if (gamesPlayed == 0) return "0%";
        int percentage = (int)((double)gamesWon / gamesPlayed * 100);
        return percentage + "%";
    }

    /**
     * Generuje sformatowany tekst do wyświetlenia na liście wyboru profili.
     * Zawiera nazwę, statystyki liczbowe oraz procent wygranych.
     *
     * @return Czytelny ciąg znaków z informacjami o profilu.
     */
    public String getDisplayInfo() {
        return name + " | Mecze: " + gamesPlayed + " | Wygrane: " + gamesWon + " (" + getWinRate() + ")";
    }

    /**
     * Zwraca reprezentację tekstową profilu w formacie do zapisu w pliku.
     * Pola oddzielone są średnikami.
     *
     * @return String w formacie "nazwa;rozegrane;wygrane".
     */
    @Override
    public String toString() {
        return name + ";" + gamesPlayed + ";" + gamesWon;
    }
}