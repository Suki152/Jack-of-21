package com.jack_of_21;

import javafx.fxml.FXML;

/**
 * Kontroler odpowiedzialny za obsługę widoku autorów projektu.
 * Wyświetla informacje o twórcach gry "Jack of 21".
 * * @author Jakub Bąk
 */
public class AuthorsController {
    /**
     * Obsługuje powrót do głównego menu aplikacji.
     * Wykorzystuje narzędzie SceneUtils do przełączenia widoku na menu.fxml.
     * * @author Jakub Bąk
     */
    @FXML
    private void onBack() {
        SceneUtils.changeScene("menu.fxml");
    }
}