package com.jack_of_21;

import javafx.fxml.FXML;

/**
 * Kontroler widoku informacyjnego (Info/Credits).
 * Obsługuje prostą nawigację powrotną do menu głównego.
 *
 * @author Jakub Bąk
 */
public class InfoController {
    /**
     * Obsługuje kliknięcie przycisku "Wstecz".
     * Przełącza scenę na menu główne.
     */
    @FXML
    private void onBack() {
        SceneUtils.changeScene("menu.fxml");
    }
}
