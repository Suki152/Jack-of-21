package com.jack_of_21;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Klasa implementująca rdzeń logiki gry "Jack of 21".
 * Odpowiada za zarządzanie talią, obliczanie punktów, obsługę tur,
 * mechanikę kart specjalnych, logikę AI oraz weryfikację warunków
 * zwycięstwa rundy i całej partii.
 *
 * @author Jakub Bąk
 */
public class GameLogic {
    /** Obiekt reprezentujący gracza lokalnego (lub Hosta w multi). */
    private Player player = new Player();
    /** Obiekt reprezentujący przeciwnika (AI lub Klienta w multi). */
    private Player opponent = new Player();
    /** Lista kart stanowiąca aktualną talię w grze. */
    private List<Card> deck = new ArrayList<>();

    /** Ręka kart specjalnych gracza. */
    private List<SpecialCardType> playerSpecialCards = new ArrayList<>();
    /** Ręka kart specjalnych przeciwnika. */
    private List<SpecialCardType> opponentSpecialCards = new ArrayList<>();

    /** Flaga oznaczająca definitywny koniec całej gry (czyjeś HP spadło do 0). */
    private boolean gameEnded = false;
    /** Flaga oznaczająca koniec bieżącej rundy. */
    private boolean roundEnded = false;
    /** Flaga wskazująca, czyja jest tura (true = gracz, false = przeciwnik). */
    private boolean playerTurn = true;

    /** Punkty życia (HP) gracza. Startowo 11. */
    private int playerHP = 11;
    /** Punkty życia (HP) przeciwnika. Startowo 11. */
    private int opponentHP = 11;
    /** Aktualna stawka zakładu (obrażenia zadawane po rundzie). */
    private int currentBet = 1;

    /** Czy gracz spasował w danej rundzie. */
    private boolean playerStand = false;
    /** Czy przeciwnik spasował w danej rundzie. */
    private boolean opponentStand = false;
    /** Flaga pomocnicza wykrywająca sytuację, gdy obaj gracze spasowali pod rząd. */
    private boolean bothStoodInSequence = false;

    /** Numer bieżącej rundy. */
    private int roundNumber = 0;

    /** Zwycięzca bieżącej rundy. */
    private Winner roundWinner = null;
    /** Zwycięzca całej gry. */
    private Winner gameWinner = null;

    /** Wyświetlana nazwa hosta (gracza głównego). */
    private String hostName = "Host";
    /** Wyświetlana nazwa klienta (przeciwnika). */
    private String clientName = "Oczekiwanie...";

    /**
     * Definiuje możliwe wyniki rozstrzygnięcia rundy lub gry.
     * @author Jakub Bąk
     */
    public enum Winner {
        PLAYER, OPPONENT, TIE
    }

    /**
     * Inicjalizuje nową sesję gry i przygotowuje pierwszą rundę.
     * @author Jakub Bąk
     */
    public GameLogic() {
        startNewRound();
    }

    /**
     * Generuje nową talię 11 kart (o wartościach 1-11) i przeprowadza tasowanie.
     * @author Jakub Bąk
     */
    private void initializeDeck() {
        deck.clear();
        for (int i = 1; i <= 11; i++) {
            deck.add(new Card(i));
        }
        Collections.shuffle(deck);
    }

    /**
     * Procedura rozpoczęcia nowej rundy. Resetuje ręce graczy, odnawia talię
     * oraz losuje karty specjalne dla obu uczestników.
     * @author Jakub Bąk
     * @author Kacper Chojnacki
     */
    public void startNewRound() {
        roundNumber++;
        player.clearHand();
        opponent.clearHand();
        playerStand = false;
        opponentStand = false;
        roundEnded = false;
        playerTurn = true;
        bothStoodInSequence = false;
        roundWinner = null;
        gameWinner = null;


        initializeDeck();

        if (!deck.isEmpty()) player.addCard(deck.remove(0));
        if (!deck.isEmpty()) opponent.addCard(deck.remove(0));
        if (!deck.isEmpty()) player.addCard(deck.remove(0));
        if (!deck.isEmpty()) opponent.addCard(deck.remove(0));

        drawSpecialCards(playerSpecialCards);
        drawSpecialCards(opponentSpecialCards);
    }

    /**
     * Losuje i dodaje karty specjalne do podanej ręki, do limitu 5 kart.
     *
     * @author Kacper Chojnacki
     * @param hand Lista kart specjalnych, do której mają zostać dodane nowe.
     */
    private void drawSpecialCards(List<SpecialCardType> hand) {
        Random rand = new Random();
        SpecialCardType[] types = SpecialCardType.values();
        for (int i = 0; i < 2; i++) {
            if (hand.size() < 5) {
                hand.add(types[rand.nextInt(types.length)]);
            }
        }
    }

    /**
     * Obsługuje użycie karty specjalnej przez gracza lub przeciwnika.
     * Aplikuje odpowiednie efekty (zmiana zakładu, modyfikacja kart, wymiana ręki itp.)
     * oraz odtwarza odpowiednie dźwięki.
     *
     * @param card          Typ użytej karty specjalnej.
     * @param isPlayerUsing True, jeśli karty używa gracz (Host); False, jeśli przeciwnik.
     * @author Kacper Chojnacki
     */
    public void useSpecialCard(SpecialCardType card, boolean isPlayerUsing) {
        if (isPlayerUsing) {
            playerSpecialCards.remove(card);

            playerStand = false;

            if (card == SpecialCardType.RETURN_OPP) {
                opponentStand = false;
            }

        } else {
            opponentSpecialCards.remove(card);

            opponentStand = false;

            if (card == SpecialCardType.RETURN_OPP) {
                playerStand = false;
            }
        }

        Player user = isPlayerUsing ? player : opponent;
        Player enemy = isPlayerUsing ? opponent : player;

        // Obsługa efektów kart
        switch (card) {
            case BET_UP:
                SoundManager.getInstance().playSound(SoundManager.SoundEffect.BET_UP);
                currentBet++;
                break;
            case BET_DOWN:
                SoundManager.getInstance().playSound(SoundManager.SoundEffect.BET_DOWN);
                if (currentBet > 1) currentBet--;
                break;
            case RETURN_OWN:
                SoundManager.getInstance().playSound(SoundManager.SoundEffect.RETURN_OWN);
                Player targetSelf = isPlayerUsing ? player : opponent;
                returnLastCard(targetSelf);
                break;
            case RETURN_OPP:
                SoundManager.getInstance().playSound(SoundManager.SoundEffect.RETURN_OPP);
                Player targetEnemy = isPlayerUsing ? opponent : player;
                returnLastCard(targetEnemy);
                break;

            case SAW:
                SoundManager.getInstance().playSound(SoundManager.SoundEffect.SAW);
                List<Card> handSaw = user.getHand();
                if (!handSaw.isEmpty()) {
                    Card lastCard = handSaw.get(handSaw.size() - 1);

                    int newValue = Math.max(1, lastCard.getValue() / 2);

                    lastCard.setValue(newValue);
                }
                break;

            case MIRROR:
                SoundManager.getInstance().playSound(SoundManager.SoundEffect.MIRROR);
                List<Card> userHand = isPlayerUsing ? player.getHand() : opponent.getHand();
                List<Card> enemyHand = isPlayerUsing ? opponent.getHand() : player.getHand();

                if (!userHand.isEmpty() && !enemyHand.isEmpty()) {
                    Card myLast = userHand.remove(userHand.size() - 1);
                    Card enemyLast = enemyHand.remove(enemyHand.size() - 1);

                    userHand.add(enemyLast);
                    enemyHand.add(myLast);
                }
                break;

            case LCK7:
                SoundManager.getInstance().playSound(SoundManager.SoundEffect.LCK7);
                List<Card> hand = user.getHand();
                if (!hand.isEmpty()) {
                    Card lastCard = hand.get(hand.size() - 1);
                    lastCard.setValue(7);

                    if (isPlayerUsing) playerStand = false;
                    else opponentStand = false;
                }
                break;

        }
    }

    /**
     * Pomocnicza metoda dla kart specjalnych typu RETURN.
     * Zwraca ostatnią kartę z ręki celu do talii i tasuje talię.
     *
     * @param target Gracz, któremu zabierana jest karta.
     * @author Kacper Chojnacki
     */
    private void returnLastCard(Player target) {
        List<Card> hand = target.getHand();
        if (!hand.isEmpty()) {
            Card removed = hand.remove(hand.size() - 1);
            deck.add(removed);
            Collections.shuffle(deck);
        }
    }

    /**
     * Wykonuje ruch dobrania karty (HIT) przez gracza.
     * Zmienia turę na przeciwnika, jeśli runda trwa.
     */
    public void playerHit() {
        if (!roundEnded && playerTurn && !playerStand && !deck.isEmpty()) {
            player.addCard(deck.remove(0));
            opponentStand = false;
            playerTurn = false;
        }
    }

    /**
     * Wykonuje ruch spasowania (STAND) przez gracza.
     * Jeśli przeciwnik też spasował, kończy rundę.
     */
    public void playerStand() {
        if (!roundEnded && playerTurn && !playerStand) {
            playerStand = true;
            playerTurn = false;

            if (opponentStand) {
                bothStoodInSequence = true;
                endRound();
            } else {
            }
        }
    }

    /**
     * Wykonuje ruch dobrania karty (HIT) przez przeciwnika.
     */
    public void opponentHit() {
        if (!roundEnded && !playerTurn && !opponentStand && !deck.isEmpty()) {
            opponent.addCard(deck.remove(0));
            playerStand = false;
            playerTurn = true;
        }
    }

    /**
     * Wykonuje ruch spasowania (STAND) przez przeciwnika.
     */
    public void opponentStand() {
        if (!roundEnded && !playerTurn && !opponentStand) {
            opponentStand = true;
            playerTurn = true;

            if (playerStand) {
                bothStoodInSequence = true;
                endRound();
            }
        }
    }

    /**
     * Wykonuje logikę sztucznej inteligencji (AI) dla trybu Single Player.
     * Decyduje, czy dobrać kartę, czy spasować, w zależności od wyniku.
     *
     * @return true, jeśli AI dobrało kartę; false, jeśli spasowało.
     * @author Jakub Bąk
     * @author Kacper Chojnacki
     */
    public boolean makeAIMove() {
        if (!roundEnded && !playerTurn && !opponentStand) {
            if (opponent.getScore() < 16 && !deck.isEmpty()) {
                opponentHit();
                return true;
            } else {
                opponentStand();
                return true;
            }
        }
        return false;
    }

    /**
     * Finalizuje rundę, oblicza wyniki, wyłania zwycięzcę rundy
     * i aktualizuje punkty życia (HP) graczy. Sprawdza warunek końca gry.
     *
     * @author Jakub Bąk
     */
    private void endRound() {
        roundEnded = true;

        int playerScore = player.getScore();
        int opponentScore = opponent.getScore();

        boolean playerWins = false;
        boolean opponentWins = false;

        if (playerScore > 21 && opponentScore > 21) {
            roundWinner = Winner.TIE;
        } else if (playerScore > 21) {
            opponentWins = true;
            roundWinner = Winner.OPPONENT;
        } else if (opponentScore > 21) {
            playerWins = true;
            roundWinner = Winner.PLAYER;
        } else if (playerScore > opponentScore) {
            playerWins = true;
            roundWinner = Winner.PLAYER;
        } else if (opponentScore > playerScore) {
            opponentWins = true;
            roundWinner = Winner.OPPONENT;
        } else {
            roundWinner = Winner.TIE;
        }

        // Aktualizacja HP
        if (playerWins) {
            playerHP += currentBet;
            opponentHP -= currentBet;
        } else if (opponentWins) {
            opponentHP += currentBet;
            playerHP -= currentBet;
        }

        currentBet++; // Zwiększenie zakładu na kolejną rundę

        // Sprawdzenie warunku końca gry
        if (playerHP <= 0 || opponentHP <= 0) {
            gameEnded = true;
            if (playerHP <= 0 && opponentHP <= 0) {
                gameWinner = Winner.TIE;
            } else if (playerHP <= 0) {
                gameWinner = Winner.OPPONENT;
            } else {
                gameWinner = Winner.PLAYER;
            }
        }
    }

    /**
     * Rozpoczyna kolejną rundę, jeśli gra się jeszcze nie zakończyła.
     */
    public void startNextRound() {
        if (!gameEnded) {
            startNewRound();
        }
    }

    /**
     * Oblicza widoczny wynik przeciwnika (ukrywa pierwszą kartę).
     * Używane w UI, aby gracz nie widział pełnego wyniku rywala w trakcie rundy.
     *
     * @return Suma punktów widocznych kart przeciwnika.
     */
    public int getOpponentVisibleScore() {
        List<Card> opponentHand = opponent.getHand();
        if (opponentHand.size() <= 1) {
            return 0;
        }
        int visibleScore = 0;
        for (int i = 1; i < opponentHand.size(); i++) {
            visibleScore += opponentHand.get(i).getValue();
        }
        return visibleScore;
    }

    public int getPlayerFullScore() { return player.getScore(); }
    public int getOpponentFullScore() { return opponent.getScore(); }

    public void setPlayerTurn(boolean playerTurn) {
        this.playerTurn = playerTurn;
    }

    /**
     * Tworzy obiekt GameState reprezentujący aktualny stan rozgrywki.
     * Obiekt ten jest gotowy do wysłania przez sieć.
     *
     * @return Obiekt GameState z bieżącymi danymi.
     * @author Jakub Bąk
     */
    public GameState createGameState() {
        GameState state = new GameState();

        for (Card card : player.getHand()) {
            state.getPlayerHand().add(card.getValue());
        }
        for (Card card : opponent.getHand()) {
            state.getOpponentHand().add(card.getValue());
        }

        state.setPlayerTurn(playerTurn);
        state.setRoundEnded(roundEnded);
        state.setGameEnded(gameEnded);
        state.setPlayerHP(playerHP);
        state.setOpponentHP(opponentHP);
        state.setCurrentBet(currentBet);

        state.setPlayerStand(playerStand);
        state.setOpponentStand(opponentStand);
        state.setBothStoodInSequence(bothStoodInSequence);
        state.setRoundWinner(roundWinner != null ? roundWinner.name() : null);
        state.setGameWinner(gameWinner != null ? gameWinner.name() : null);

        state.setHostName(hostName);
        state.setClientName(clientName);

        for (SpecialCardType sc : playerSpecialCards) {
            state.getPlayerSpecialHand().add(sc.name());
        }
        for (SpecialCardType sc : opponentSpecialCards) {
            state.getOpponentSpecialHand().add(sc.name());
        }

        state.setRoundNumber(roundNumber);

        List<Integer> deckValues = deck.stream().map(Card::getValue).collect(Collectors.toList());
        state.setDeckState(deckValues);

        return state;
    }

    /**
     * Aktualizuje lokalną logikę gry na podstawie otrzymanego stanu gry (GameState).
     * Służy do synchronizacji klienta z hostem.
     *
     * @param state Otrzymany obiekt stanu gry.
     * @author Jakub Bąk
     * @author Kacper Chojnacki
     */
    public void applyGameState(GameState state) {
        // Klient nie potrzebuje pełnej talii, tylko ją czyści
        this.deck.clear();
        if (state.getDeckState() != null) {
            for (Integer val : state.getDeckState()) {
                this.deck.add(new Card(val));
            }
        }

        if (state.getRoundNumber() > this.roundNumber) {
            this.roundNumber = state.getRoundNumber();
        }

        player.clearHand();
        opponent.clearHand();

        for (Integer value : state.getPlayerHand()) {
            player.addCard(new Card(value));
        }
        for (Integer value : state.getOpponentHand()) {
            opponent.addCard(new Card(value));
        }

        playerTurn = state.isPlayerTurn();
        roundEnded = state.isRoundEnded();
        gameEnded = state.isGameEnded();
        playerHP = state.getPlayerHP();
        opponentHP = state.getOpponentHP();
        currentBet = state.getCurrentBet();

        playerStand = state.isPlayerStand();
        opponentStand = state.isOpponentStand();
        bothStoodInSequence = state.isBothStoodInSequence();

        if (state.getRoundWinner() != null) {
            roundWinner = Winner.valueOf(state.getRoundWinner());
        }
        if (state.getGameWinner() != null) {
            gameWinner = Winner.valueOf(state.getGameWinner());
        }

        // Nazwy aktualizujemy tylko jeśli przyszły (zwykle w Handshake)
        if (state.getHostName() != null) this.hostName = state.getHostName();
        if (state.getClientName() != null) this.clientName = state.getClientName();

        playerSpecialCards.clear();
        for (String s : state.getPlayerSpecialHand()) {
            playerSpecialCards.add(SpecialCardType.valueOf(s));
        }
        opponentSpecialCards.clear();
        for (String s : state.getOpponentSpecialHand()) {
            opponentSpecialCards.add(SpecialCardType.valueOf(s));
        }
    }

    // Gettery i Settery
    public List<SpecialCardType> getPlayerSpecialCards() { return playerSpecialCards; }
    public List<SpecialCardType> getOpponentSpecialCards() { return opponentSpecialCards; }

    public String getHostName() { return hostName; }
    public void setHostName(String hostName) { this.hostName = hostName; }

    public String getClientName() { return clientName; }
    public void setClientName(String clientName) { this.clientName = clientName; }

    public Player getPlayer() { return player; }
    public Player getOpponent() { return opponent; }
    public List<Card> getDeck() { return deck; }
    public boolean isGameEnded() { return gameEnded; }
    public boolean isRoundEnded() { return roundEnded; }
    public boolean isPlayerTurn() { return playerTurn; }
    public int getPlayerHP() { return playerHP; }
    public int getOpponentHP() { return opponentHP; }
    public int getCurrentBet() { return currentBet; }
    public void setCurrentBet(int bet) { this.currentBet = bet; }
    public boolean isPlayerStand() { return playerStand; }
    public boolean isOpponentStand() { return opponentStand; }
    public boolean isBothStoodInSequence() { return bothStoodInSequence; }
    public Winner getRoundWinner() { return roundWinner; }
    public Winner getGameWinner() { return gameWinner; }
}