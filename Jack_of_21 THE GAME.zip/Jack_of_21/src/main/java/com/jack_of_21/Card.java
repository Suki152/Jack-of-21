package com.jack_of_21;

/**
 * Klasa reprezentująca pojedynczą kartę w mechanice gry.
 * Przechowuje wartość liczbową karty, która jest sumowana podczas rozgrywki.
 * * @author Jakub Bąk
 */
public class Card {
    /** Wartość punktowa karty. */
    private int value;

    /**
     * Tworzy nowy obiekt karty o zadanej wartości.
     * * @param value Liczba punktów przypisana do karty.
     * @author Jakub Bąk
     */
    public Card(int value) {
        this.value = value;
    }

    /**
     * Pozwala na zmianę wartości karty w trakcie gry (np. przez karty specjalne).
     * * @param value Nowa wartość punktowa.
     * @author Jakub Bąk
     */
    public void setValue(int value) {
        this.value = value;
    }

    /**
     * Pobiera aktualną wartość punktową karty.
     * * @return Wartość karty.
     * @author Jakub Bąk
     */
    public int getValue() {
        return value;
    }
}
