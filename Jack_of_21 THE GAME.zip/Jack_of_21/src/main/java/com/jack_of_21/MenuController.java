package com.jack_of_21;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Slider;
import javafx.stage.Stage;

/**
 * Kontroler głównego menu gry.
 * Obsługuje nawigację do poszczególnych sekcji (gra, połączenie, autorzy, info),
 * wybór skórek kart oraz ustawienia głośności dźwięku i muzyki.
 *
 * @author Jakub Bąk
 * @author Kacper Chojnacki
 */
public class MenuController {

    @FXML private ComboBox<String> skinSelector;

    @FXML private Slider musicSlider;
    @FXML private Slider sfxSlider;

    /**
     * Inicjalizuje kontroler menu.
     * Konfiguruje listę wyboru skórek, ustawia początkowe wartości suwaków głośności
     * oraz podpina listenery zmian wartości do `SoundManager`.
     * Uruchamia muzykę w tle dla menu.
     */
    @FXML
    private void initialize() {
        // --- 1. Konfiguracja Skinów ---
        if (skinSelector != null) {
            SkinManager skinManager = SkinManager.getInstance();
            skinSelector.getItems().addAll(skinManager.getAvailableSkins());
            skinSelector.setValue(skinManager.getCurrentSkin());

            skinSelector.setOnAction(event -> {
                SoundManager.getInstance().playSound(SoundManager.SoundEffect.CLICK);
                String selected = skinSelector.getValue();
                if (selected != null) {
                    skinManager.setSkin(selected);
                }
            });
        }

        // --- 2. Konfiguracja Suwaków Głośności ---
        if (musicSlider != null && sfxSlider != null) {
            SoundManager sound = SoundManager.getInstance();

            // Ustaw suwaki na aktualną głośność z Managera
            musicSlider.setValue(sound.getMusicVolume());
            sfxSlider.setValue(sound.getSfxVolume());

            // Dodaj nasłuchiwanie zmian (Listener)
            musicSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
                sound.setMusicVolume(newVal.doubleValue());
            });

            sfxSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
                sound.setSfxVolume(newVal.doubleValue());
            });
        }

        // --- 3. Start Muzyki ---
        SoundManager.getInstance().playBackgroundMusic(SoundManager.MusicType.MENU);
    }

    /**
     * Obsługuje przycisk rozpoczęcia gry wieloosobowej (przejście do ekranu połączenia).
     * @param e Zdarzenie kliknięcia.
     * @throws Exception W razie błędu ładowania sceny.
     */
    @FXML
    private void onStart(ActionEvent e) throws Exception {
        SoundManager.getInstance().playSound(SoundManager.SoundEffect.CLICK);
        SceneUtils.changeScene("connection.fxml");
    }

    /**
     * Obsługuje przycisk rozpoczęcia gry jednoosobowej (Single Player).
     * @param e Zdarzenie kliknięcia.
     * @throws Exception W razie błędu ładowania sceny.
     */
    @FXML
    private void onSinglePlayer(ActionEvent e) throws Exception {
        SoundManager.getInstance().playSound(SoundManager.SoundEffect.CLICK);
        SceneUtils.changeScene("game.fxml");
    }

    /**
     * Obsługuje przycisk przejścia do ekranu autorów.
     * @param e Zdarzenie kliknięcia.
     * @throws Exception W razie błędu ładowania sceny.
     */
    @FXML
    private void onAuthors(ActionEvent e) throws Exception {
        SoundManager.getInstance().playSound(SoundManager.SoundEffect.CLICK);
        SceneUtils.changeScene("authors.fxml");
    }

    /**
     * Obsługuje przycisk przejścia do ekranu informacji/pomocy.
     * @param e Zdarzenie kliknięcia.
     * @throws Exception W razie błędu ładowania sceny.
     */
    @FXML
    private void onInfo(ActionEvent e) throws Exception {
        SoundManager.getInstance().playSound(SoundManager.SoundEffect.CLICK);
        SceneUtils.changeScene("info.fxml");
    }

    /**
     * Obsługuje przycisk wyjścia z aplikacji.
     * @param e Zdarzenie kliknięcia.
     */
    @FXML
    private void onQuit(ActionEvent e) {
        System.exit(0);
    }
}