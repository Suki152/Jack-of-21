package com.jack_of_21;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * Główna klasa startowa aplikacji "Jack of 21".
 * Inicjalizuje środowisko JavaFX, ładuje ekran powitalny (logowania)
 * oraz zarządza cyklem życia aplikacji.
 *
 * @author Jakub Bąk
 */
public class Main extends Application {

    /**
     * Metoda startowa JavaFX.
     * Ładuje widok `login.fxml`, ustawia tytuł okna, wymiary sceny
     * oraz uruchamia muzykę w tle. Rejestruje również handler zamykania okna.
     *
     * @param primaryStage Główne okno (Stage) aplikacji.
     * @throws Exception W przypadku błędu ładowania pliku FXML.
     */
    @Override
    public void start(Stage primaryStage) throws Exception {
        // Ładujemy najpierw ekran logowania
        FXMLLoader loader = new FXMLLoader(getClass().getResource("login.fxml"));
        Scene scene = new Scene(loader.load(), 1000, 700);
        primaryStage.setTitle("Jack of 21");
        primaryStage.setScene(scene);
        primaryStage.show();
        SoundManager.getInstance().playBackgroundMusic(SoundManager.MusicType.MENU);

        primaryStage.setOnCloseRequest(event -> {
            System.out.println("Zamykanie aplikacji...");
            NetworkManager.getInstance().disconnect();
        });
    }

    /**
     * Metoda wywoływana przy zatrzymywaniu aplikacji.
     * Służy do zwolnienia zasobów, np. rozłączenia połączenia sieciowego.
     *
     * @throws Exception W przypadku błędu podczas zatrzymywania.
     */
    @Override
    public void stop() throws Exception {
        NetworkManager.getInstance().disconnect();
        super.stop();
    }

    /**
     * Punkt wejścia do programu.
     * Uruchamia aplikację JavaFX.
     *
     * @param args Argumenty wiersza poleceń.
     */
    public static void main(String[] args) {
        launch(args);
    }
}