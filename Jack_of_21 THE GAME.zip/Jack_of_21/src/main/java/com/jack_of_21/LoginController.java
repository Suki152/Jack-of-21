package com.jack_of_21;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.ListView;
import javafx.scene.control.Label;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import java.util.Optional;

import javafx.scene.control.DialogPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Region;

/**
 * Kontroler ekranu logowania i wyboru profilu.
 * Umożliwia tworzenie nowych profili graczy, wybór istniejących,
 * ich usuwanie oraz walidację wprowadzanych nazw.
 *
 * @author Jakub Bąk
 * @author Kacper Chojnacki
 */
public class LoginController {

    @FXML private TextField nameField;
    @FXML private ListView<String> profilesList;
    @FXML private Label errorLabel;

    /**
     * Metoda inicjalizująca kontroler.
     * Ładuje listę profili i ustawia listenery na liście oraz polu tekstowym,
     * aby dynamicznie aktualizować interfejs (np. czyszczenie błędów przy pisaniu).
     */
    @FXML
    private void initialize() {
        refreshProfileList();

        // Jak klikniesz na listę, to wpisuje nick do pola tekstowego i czyści błędy
        profilesList.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                String nick = newValue.split(" \\| ")[0];
                nameField.setText(nick);
                errorLabel.setText(""); // Czyścimy błąd po wybraniu z listy
            }
        });

        // Czyścimy błąd gdy użytkownik zaczyna pisać
        nameField.textProperty().addListener((obs, oldVal, newVal) -> {
            errorLabel.setText("");
        });
    }

    /**
     * Odświeża listę wyświetlanych profili na podstawie danych z ProfileManager.
     */
    private void refreshProfileList() {
        profilesList.getItems().clear();
        for (PlayerProfile p : ProfileManager.getAllProfiles()) {
            profilesList.getItems().add(p.getDisplayInfo());
        }
    }

    /**
     * Obsługuje usuwanie wybranego profilu.
     * Wyświetla okno dialogowe z prośbą o potwierdzenie operacji.
     */
    @FXML
    private void onDeleteProfile() {
        String selected = profilesList.getSelectionModel().getSelectedItem();
        if (selected == null) {
            errorLabel.setText("Zaznacz profil na liście, aby go usunąć.");
            return;
        }

        String nick = selected.split(" \\| ")[0];

        // Alert potwierdzenia
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Usuwanie profilu");
        alert.setHeaderText("Czy na pewno chcesz usunąć profil: " + nick + "?");
        alert.setContentText("Tej operacji nie można cofnąć.");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            ProfileManager.deleteProfile(nick);
            refreshProfileList();
            nameField.setText("");
            errorLabel.setText("Profil '" + nick + "' został usunięty.");
        }
    }

    /**
     * Obsługuje próbę zalogowania się.
     * Waliduje nazwę gracza, sprawdza czy profil istnieje.
     * Jeśli profil nie istnieje, proponuje jego utworzenie.
     */
    @FXML
    private void onLogin() {
        // Resetujemy komunikat błędu na początku
        errorLabel.setText("");

        String name = nameField.getText().trim();

        if (name.isEmpty()) {
            errorLabel.setText("Podaj nazwę gracza!");
            return;
        }

        if (name.length() > 9) {
            errorLabel.setText("Nazwa zbyt długa! (Max 9 znaków)");
            return;
        }

        PlayerProfile profile = ProfileManager.getProfile(name);

        if (profile != null) {
            ProfileManager.setCurrentProfile(profile);
            loginSuccess(profile);
        } else {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Nowy gracz");
            alert.setHeaderText("Konto '" + name + "' nie istnieje.");
            alert.setContentText("Czy chcesz utworzyć nowy profil?");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                PlayerProfile newProfile = ProfileManager.createProfile(name);
                ProfileManager.setCurrentProfile(newProfile);
                loginSuccess(newProfile);
            }
        }
    }

    /**
     * Wyświetla stylizowany komunikat o pomyślnym zalogowaniu
     * i przenosi użytkownika do menu głównego gry.
     *
     * @param p Profil zalogowanego gracza.
     */
    private void loginSuccess(PlayerProfile p) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Sukces");
        alert.setHeaderText(null);
        alert.setContentText("Zalogowano jako: " + p.getName() + "\nWin Rate: " + p.getWinRate());

        DialogPane dialogPane = alert.getDialogPane();

        dialogPane.setStyle("-fx-background-color: #2c3e50;");

        dialogPane.setMinHeight(Region.USE_PREF_SIZE);

        Label contentLabel = (Label) dialogPane.lookup(".content.label");
        if (contentLabel != null) {
            contentLabel.setStyle("-fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold;");
        }

        dialogPane.lookupButton(ButtonType.OK).setStyle(
                "-fx-background-color: #e74c3c; " +
                        "-fx-text-fill: white; " +
                        "-fx-font-size: 14px;"
        );

        try {
            ImageView icon = new ImageView(new Image(getClass().getResourceAsStream("/logo.png")));
            icon.setFitHeight(50);
            icon.setFitWidth(50);
            alert.setGraphic(icon);
        } catch (Exception e) {
            System.out.println("Nie udało się załadować ikony do alertu.");
        }

        alert.showAndWait();

        SceneUtils.changeScene("menu.fxml");
    }
}