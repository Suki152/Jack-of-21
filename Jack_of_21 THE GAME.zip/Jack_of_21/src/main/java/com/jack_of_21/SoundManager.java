package com.jack_of_21;

import javafx.scene.media.AudioClip;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import java.net.URL;

/**
 * Singleton odpowiedzialny za system audio w aplikacji.
 * Zarządza odtwarzaniem muzyki w tle (loop) oraz efektów dźwiękowych (SFX).
 * Umożliwia globalną kontrolę głośności.
 *
 * @author Kacper Chojnacki
 */
public class SoundManager {
    /** Instancja singletona. */
    private static SoundManager instance;
    /** Odtwarzacz muzyki w tle (obsługuje dłuższe pliki audio). */
    private MediaPlayer backgroundPlayer;

    // --- ZMIENNE GŁOŚNOŚCI (Domyślnie 50%) ---
    /** Aktualny poziom głośności muzyki (0.0 - 1.0). */
    private double musicVolume = 0.5;
    /** Aktualny poziom głośności efektów dźwiękowych (0.0 - 1.0). */
    private double sfxVolume = 0.5;

    /**
     * Typ wyliczeniowy definiujący ścieżki do plików muzycznych.
     */
    public enum MusicType {
        MENU("/com/jack_of_21/sounds/menu_music.mp3"),
        GAME("/com/jack_of_21/sounds/game_music.mp3"),
        WIN("/com/jack_of_21/sounds/win_music.mp3"),
        LOSS("/com/jack_of_21/sounds/loss_music.mp3");

        private final String path;
        MusicType(String path) { this.path = path; }
        public String getPath() { return path; }
    }

    /**
     * Typ wyliczeniowy definiujący ścieżki do efektów dźwiękowych (SFX).
     */
    public enum SoundEffect {
        CLICK("/com/jack_of_21/sounds/sfx/click.mp3"),
        WIN_SFX("/com/jack_of_21/sounds/sfx/win_sfx.mp3"),
        LOSS_SFX("/com/jack_of_21/sounds/sfx/loss_sfx.mp3"),
        HIT("/com/jack_of_21/sounds/sfx/hit.mp3"),
        STAND("/com/jack_of_21/sounds/sfx/stand.mp3"),
        BET_UP("/com/jack_of_21/sounds/sfx/bet_up.mp3"),
        BET_DOWN("/com/jack_of_21/sounds/sfx/bet_down.mp3"),
        RETURN_OWN("/com/jack_of_21/sounds/sfx/return_own.mp3"),
        RETURN_OPP("/com/jack_of_21/sounds/sfx/return_opp.mp3"),
        SAW("/com/jack_of_21/sounds/sfx/saw.mp3"),
        MIRROR("/com/jack_of_21/sounds/sfx/mirror.mp3"),
        LCK7("/com/jack_of_21/sounds/sfx/lck7.mp3");

        private final String path;
        SoundEffect(String path) { this.path = path; }
        public String getPath() { return path; }
    }

    /**
     * Pobiera instancję menedżera dźwięku.
     * @return Jedyna instancja SoundManager.
     */
    public static SoundManager getInstance() {
        if (instance == null) instance = new SoundManager();
        return instance;
    }

    private SoundManager() {}

    // --- METODY STEROWANIA GŁOŚNOŚCIĄ ---

    /**
     * Ustawia globalną głośność muzyki.
     * Jeśli muzyka jest aktualnie odtwarzana, zmiana jest aplikowana natychmiast.
     *
     * @param volume Poziom głośności (0.0 do 1.0).
     */
    public void setMusicVolume(double volume) {
        this.musicVolume = volume;
        if (backgroundPlayer != null) {
            backgroundPlayer.setVolume(musicVolume);
        }
    }

    /**
     * Ustawia globalną głośność efektów dźwiękowych.
     * @param volume Poziom głośności (0.0 do 1.0).
     */
    public void setSfxVolume(double volume) {
        this.sfxVolume = volume;
    }

    public double getMusicVolume() { return musicVolume; }
    public double getSfxVolume() { return sfxVolume; }

    // ------------------------------------------

    /**
     * Odtwarza muzykę w tle. Zatrzymuje poprzednio odtwarzany utwór.
     * Obsługuje zapętlanie dla muzyki menu i gry oraz jednokrotne odtworzenie
     * dla muzyki zwycięstwa/porażki.
     *
     * @param type Typ muzyki do odtworzenia.
     */
    public void playBackgroundMusic(MusicType type) {
        if (backgroundPlayer != null) {
            try {
                backgroundPlayer.stop();
                backgroundPlayer.dispose();
            } catch (Exception e) {}
            backgroundPlayer = null;
        }

        try {
            URL resource = getClass().getResource(type.getPath());
            if (resource == null) return;

            Media media = new Media(resource.toExternalForm());
            backgroundPlayer = new MediaPlayer(media);

            if (type == MusicType.MENU || type == MusicType.GAME) {
                backgroundPlayer.setCycleCount(MediaPlayer.INDEFINITE);
            } else {
                backgroundPlayer.setCycleCount(1);
            }

            backgroundPlayer.setVolume(musicVolume);
            backgroundPlayer.play();

        } catch (Exception e) {
            System.err.println("Błąd muzyki: " + e.getMessage());
        }
    }

    /**
     * Odtwarza krótki efekt dźwiękowy. Używa klasy AudioClip, co pozwala
     * na równoległe odtwarzanie wielu dźwięków bez przerywania muzyki.
     *
     * @param effect Efekt dźwiękowy do odtworzenia.
     */
    public void playSound(SoundEffect effect) {
        try {
            URL resource = getClass().getResource(effect.getPath());
            if (resource != null) {
                AudioClip clip = new AudioClip(resource.toExternalForm());
                clip.setVolume(sfxVolume);
                clip.play();
            }
        } catch (Exception e) { }
    }

    /**
     * Zatrzymuje aktualnie odtwarzaną muzykę w tle.
     */
    public void stopMusic() {
        if (backgroundPlayer != null) backgroundPlayer.stop();
    }
}