package com.jack_of_21;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage; //
import javafx.geometry.Rectangle2D;
import javafx.stage.Screen;

/**
 * Klasa narzędziowa wspomagająca zarządzanie scenami (widokami) w JavaFX.
 * Odpowiada za przełączanie plików FXML przy zachowaniu rozmiaru i pozycji okna,
 * co zapewnia płynne przejścia między ekranami menu i gry.
 *
 * @author Jakub Bąk
 * @author Kacper Chojnacki
 */
public class SceneUtils {

    /**
     * Zmienia aktualnie wyświetlaną scenę w głównym oknie aplikacji.
     * Ładuje nowy widok z pliku FXML, jednocześnie zapamiętując i przywracając
     * wymiary oraz pozycję okna, aby zapobiec jego "skakaniu" po pulpicie.
     * W przypadku pierwszego uruchomienia centruje okno na ekranie.
     *
     * @param fxml Nazwa pliku FXML do załadowania (np. "game.fxml").
     */
    public static void changeScene(String fxml) {
        try {
            Stage stage = (Stage) javafx.stage.Window.getWindows().get(0);

            // Zapamiętanie aktualnych wymiarów i pozycji
            double width = stage.getWidth();
            double height = stage.getHeight();
            double x = stage.getX();
            double y = stage.getY();

            // Wczytanie nowej sceny
            Scene newScene = new Scene(FXMLLoader.load(SceneUtils.class.getResource(fxml)), width, height);
            stage.setScene(newScene);

            // Przywrócenie pozycji i wymiarów
            stage.setWidth(width);
            stage.setHeight(height);
            stage.setX(x);
            stage.setY(y);

            // Centrowanie przy pierwszym uruchomieniu (gdy okno było zminimalizowane)
            if (Double.isNaN(x) || Double.isNaN(y)) {
                Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();
                stage.setX((screenBounds.getWidth() - width) / 2);
                stage.setY((screenBounds.getHeight() - height) / 2);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
