package com.jack_of_21;

import java.util.Arrays;
import java.util.List;

/**
 * Singleton zarządzający motywami graficznymi (skórkami) w grze.
 * Pozwala na zmianę wyglądu kart i elementów gry poprzez dynamiczne
 * generowanie ścieżek do zasobów graficznych.
 *
 * @author Jakub Bąk
 * @author Kacper Chojnacki
 */
public class SkinManager {
    /** Instancja singletona. */
    private static SkinManager instance;
    /** Nazwa aktualnie wybranego folderu ze skórką (domyślnie "Basic"). */
    private String currentSkin = "Basic";

    /**
     * Lista dostępnych skinów.
     * Nazwy te muszą odpowiadać fizycznym folderom w resources/com/jack_of_21/skins.
     */
    private final List<String> availableSkins = Arrays.asList("Basic", "StarShaped", "Sabacc", "Uno");

    /** Prywatny konstruktor zapobiegający tworzeniu instancji poza klasą. */
    private SkinManager() {}

    /**
     * Pobiera jedyną instancję menedżera skórek.
     * @return Instancja SkinManager.
     */
    public static SkinManager getInstance() {
        if (instance == null) {
            instance = new SkinManager();
        }
        return instance;
    }

    /**
     * Ustawia nową skórkę gry.
     * Sprawdza, czy podana nazwa znajduje się na liście dostępnych skórek.
     *
     * @param skinName Nazwa skórki do ustawienia.
     */
    public void setSkin(String skinName) {
        if (availableSkins.contains(skinName)) {
            this.currentSkin = skinName;
            System.out.println("Zmieniono skin na: " + skinName);
        }
    }

    /**
     * Pobiera nazwę aktualnie używanej skórki.
     * @return Nazwa skórki.
     */
    public String getCurrentSkin() {
        return currentSkin;
    }

    /**
     * Pobiera listę wszystkich dostępnych skórek.
     * @return Lista nazw skórek.
     */
    public List<String> getAvailableSkins() {
        return availableSkins;
    }

    // --- Metody zwracające ścieżki do obrazków ---

    /**
     * Generuje ścieżkę do pliku graficznego konkretnej karty.
     *
     * @param value Wartość karty (np. 1-11).
     * @return Ścieżka zasobu do pliku PNG karty.
     */
    public String getCardPath(int value) {
        return "/com/jack_of_21/images/skins/" + currentSkin + "/card" + value + ".png";
    }

    /**
     * Generuje ścieżkę do rewersu (tyłu) karty.
     * @return Ścieżka zasobu do pliku PNG rewersu.
     */
    public String getCardBackPath() {
        return "/com/jack_of_21/images/skins/" + currentSkin + "/card_back.png";
    }

    /**
     * Generuje ścieżkę do ikony karty specjalnej.
     *
     * @param typeName Nazwa typu karty specjalnej (np. "SAW").
     * @return Ścieżka zasobu do pliku PNG karty specjalnej.
     */
    public String getSpecialCardPath(String typeName) {
        return "/com/jack_of_21/images/skins/" + currentSkin + "/special_" + typeName + ".png";
    }
}