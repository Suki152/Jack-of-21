package com.jack_of_21;

import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;

/**
 * Klasa reprezentująca migawkę stanu gry w danym momencie.
 * Obiekt tej klasy jest przesyłany przez sieć, aby zsynchronizować
 * widok i dane między Hostem a Klientem.
 * Implementuje interfejs Serializable, co umożliwia konwersję obiektu do strumienia bajtów.
 *
 * @author Jakub Bąk
 * @author Kacper Chojnacki
 */
public class GameState implements Serializable {
    private static final long serialVersionUID = 1L;

    // --- DANE ROZGRYWKI ---

    /** Lista wartości kart znajdujących się w ręce gracza. */
    private List<Integer> playerHand;

    /** Lista wartości kart znajdujących się w ręce przeciwnika. */
    private List<Integer> opponentHand;

    /** Flaga określająca, czy aktualnie trwa tura gracza (true) czy przeciwnika (false). */
    private boolean playerTurn;

    /** Flaga oznaczająca zakończenie bieżącej rundy. */
    private boolean roundEnded;

    /** Flaga oznaczająca definitywne zakończenie gry (wyzerowanie HP). */
    private boolean gameEnded;

    /** Punkty życia (HP) gracza. */
    private int playerHP;

    /** Punkty życia (HP) przeciwnika. */
    private int opponentHP;

    /** Aktualna wartość zakładu (obrażenia) w danej rundzie. */
    private int currentBet;

    // --- POLA SYNCHRONIZACJI ---

    /** Czy gracz spasował (Stand). */
    private boolean playerStand;

    /** Czy przeciwnik spasował (Stand). */
    private boolean opponentStand;

    /** Flaga informująca, czy obaj gracze spasowali jeden po drugim (warunek końca rundy). */
    private boolean bothStoodInSequence;

    /** Nazwa zwycięzcy rundy (PLAYER, OPPONENT, TIE). */
    private String roundWinner;

    /** Nazwa zwycięzcy całej gry (PLAYER, OPPONENT, TIE). */
    private String gameWinner;

    // --- KARTY SPECJALNE ---

    /** Lista nazw kart specjalnych posiadanych przez gracza. */
    private List<String> playerSpecialHand;

    /** Lista nazw kart specjalnych posiadanych przez przeciwnika. */
    private List<String> opponentSpecialHand;

    /** Numer bieżącej rundy. */
    private int roundNumber;

    /// --- OPTYMALIZACJA SIECI ---
    /**
     * Stan talii kart.
     * Pole oznaczone jako `transient`, co oznacza, że NIE jest ono serializowane
     * ani wysyłane przez sieć. Talia jest zarządzana wyłącznie przez Hosta
     * i nie musi być znana Klientowi.
     */
    private transient List<Integer> deckState;

    // --- METADANE GRACZY ---

    /** Wyświetlana nazwa Hosta. */
    private String hostName;

    /** Wyświetlana nazwa Klienta. */
    private String clientName;

    /**
     * Konstruktor domyślny inicjalizujący puste listy.
     */
    public GameState() {
        playerHand = new ArrayList<>();
        opponentHand = new ArrayList<>();
        playerSpecialHand = new ArrayList<>();
        opponentSpecialHand = new ArrayList<>();
        deckState = new ArrayList<>();
    }

    // --- GETTERY I SETTERY ---

    /** Pobiera rękę gracza. @return Lista wartości kart. */
    public List<Integer> getPlayerHand() { return playerHand; }
    /** Ustawia rękę gracza. @param playerHand Lista wartości kart. */
    public void setPlayerHand(List<Integer> playerHand) { this.playerHand = playerHand; }

    /** Pobiera rękę przeciwnika. @return Lista wartości kart. */
    public List<Integer> getOpponentHand() { return opponentHand; }
    /** Ustawia rękę przeciwnika. @param opponentHand Lista wartości kart. */
    public void setOpponentHand(List<Integer> opponentHand) { this.opponentHand = opponentHand; }

    /** Sprawdza czyja jest tura. @return true jeśli gracza, false jeśli przeciwnika. */
    public boolean isPlayerTurn() { return playerTurn; }
    /** Ustawia flagę tury. @param playerTurn true dla gracza, false dla przeciwnika. */
    public void setPlayerTurn(boolean playerTurn) { this.playerTurn = playerTurn; }

    /** Sprawdza czy runda się zakończyła. @return true jeśli koniec rundy. */
    public boolean isRoundEnded() { return roundEnded; }
    /** Ustawia flagę końca rundy. @param roundEnded stan zakończenia rundy. */
    public void setRoundEnded(boolean roundEnded) { this.roundEnded = roundEnded; }

    /** Sprawdza czy gra się zakończyła. @return true jeśli koniec gry. */
    public boolean isGameEnded() { return gameEnded; }
    /** Ustawia flagę końca gry. @param gameEnded stan zakończenia gry. */
    public void setGameEnded(boolean gameEnded) { this.gameEnded = gameEnded; }

    /** Pobiera HP gracza. @return Liczba punktów życia. */
    public int getPlayerHP() { return playerHP; }
    /** Ustawia HP gracza. @param playerHP Liczba punktów życia. */
    public void setPlayerHP(int playerHP) { this.playerHP = playerHP; }

    /** Pobiera HP przeciwnika. @return Liczba punktów życia. */
    public int getOpponentHP() { return opponentHP; }
    /** Ustawia HP przeciwnika. @param opponentHP Liczba punktów życia. */
    public void setOpponentHP(int opponentHP) { this.opponentHP = opponentHP; }

    /** Pobiera aktualną stawkę zakładu. @return Wartość zakładu. */
    public int getCurrentBet() { return currentBet; }
    /** Ustawia aktualną stawkę zakładu. @param currentBet Wartość zakładu. */
    public void setCurrentBet(int currentBet) { this.currentBet = currentBet; }

    /** Sprawdza czy gracz spasował. @return true jeśli STAND. */
    public boolean isPlayerStand() { return playerStand; }
    /** Ustawia flagę spasowania gracza. @param playerStand stan spasowania. */
    public void setPlayerStand(boolean playerStand) { this.playerStand = playerStand; }

    /** Sprawdza czy przeciwnik spasował. @return true jeśli STAND. */
    public boolean isOpponentStand() { return opponentStand; }
    /** Ustawia flagę spasowania przeciwnika. @param opponentStand stan spasowania. */
    public void setOpponentStand(boolean opponentStand) { this.opponentStand = opponentStand; }

    /** Sprawdza sekwencję spasowania obu graczy. @return true jeśli obaj spasowali pod rząd. */
    public boolean isBothStoodInSequence() { return bothStoodInSequence; }
    /** Ustawia flagę sekwencji spasowania. @param bothStoodInSequence stan sekwencji. */
    public void setBothStoodInSequence(boolean bothStoodInSequence) { this.bothStoodInSequence = bothStoodInSequence; }

    /** Pobiera zwycięzcę rundy. @return Nazwa zwycięzcy lub null. */
    public String getRoundWinner() { return roundWinner; }
    /** Ustawia zwycięzcę rundy. @param roundWinner Nazwa zwycięzcy. */
    public void setRoundWinner(String roundWinner) { this.roundWinner = roundWinner; }

    /** Pobiera zwycięzcę gry. @return Nazwa zwycięzcy lub null. */
    public String getGameWinner() { return gameWinner; }
    /** Ustawia zwycięzcę gry. @param gameWinner Nazwa zwycięzcy. */
    public void setGameWinner(String gameWinner) { this.gameWinner = gameWinner; }

    /** Pobiera nazwę hosta. @return Imię hosta. */
    public String getHostName() { return hostName; }
    /** Ustawia nazwę hosta. @param hostName Imię hosta. */
    public void setHostName(String hostName) { this.hostName = hostName; }

    /** Pobiera nazwę klienta. @return Imię klienta. */
    public String getClientName() { return clientName; }
    /** Ustawia nazwę klienta. @param clientName Imię klienta. */
    public void setClientName(String clientName) { this.clientName = clientName; }

    /** Pobiera listę kart specjalnych gracza. @return Lista nazw typów kart. */
    public List<String> getPlayerSpecialHand() { return playerSpecialHand; }
    /** Ustawia listę kart specjalnych gracza. @param playerSpecialHand Lista nazw typów kart. */
    public void setPlayerSpecialHand(List<String> playerSpecialHand) { this.playerSpecialHand = playerSpecialHand; }

    /** Pobiera listę kart specjalnych przeciwnika. @return Lista nazw typów kart. */
    public List<String> getOpponentSpecialHand() { return opponentSpecialHand; }
    /** Ustawia listę kart specjalnych przeciwnika. @param opponentSpecialHand Lista nazw typów kart. */
    public void setOpponentSpecialHand(List<String> opponentSpecialHand) { this.opponentSpecialHand = opponentSpecialHand; }

    /** Pobiera numer rundy. @return Numer rundy. */
    public int getRoundNumber() { return roundNumber; }
    /** Ustawia numer rundy. @param roundNumber Numer rundy. */
    public void setRoundNumber(int roundNumber) { this.roundNumber = roundNumber; }

    /** Pobiera stan talii (nie przesyłany przez sieć). @return Lista wartości kart w talii. */
    public List<Integer> getDeckState() { return deckState; }
    /** Ustawia stan talii. @param deckState Lista wartości kart w talii. */
    public void setDeckState(List<Integer> deckState) { this.deckState = deckState; }
}