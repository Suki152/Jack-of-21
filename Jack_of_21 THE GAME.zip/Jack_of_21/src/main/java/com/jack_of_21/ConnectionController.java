package com.jack_of_21;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.application.Platform;

/**
 * Kontroler zarządzający ekranem nawiązywania połączenia sieciowego.
 * Umożliwia wybór roli (Host/Klient) oraz konfigurację adresu IP i portu.
 * Implementuje interfejs PacketListener do reagowania na zdarzenia sieciowe.
 * * @author Jakub Bąk
 */
public class ConnectionController implements NetworkManager.PacketListener {
    @FXML private TextField ipField;
    @FXML private TextField portField;
    @FXML private Button connectButton;
    @FXML private Button backButton;
    @FXML private Label statusLabel;

    /**
     * Inicjalizuje widok połączenia, ustawiając domyślne wartości pól tekstowych
     * oraz rejestrując kontroler jako słuchacza w NetworkManagerze.
     * * @author Jakub Bąk
     */
    @FXML
    private void initialize() {
        ipField.setPromptText("Zostaw puste, aby założyć serwer (Host)");
        ipField.setText("localhost");
        portField.setText("5000");
        statusLabel.setText("Zostaw IP puste dla Hosta lub wpisz 127.0.0.1 dla Klienta.");

        NetworkManager.getInstance().setPacketListener(this);
    }

    /**
     * Próbuje nawiązać połączenie jako klient lub wystartować serwer jako host.
     * Proces odbywa się w oddzielnym wątku, aby nie blokować interfejsu JavaFX.
     * * @author Jakub Bąk
     */
    @FXML
    private void onConnect() {
        String ip = ipField.getText().trim();
        String portText = portField.getText().trim();

        if (portText.isEmpty()) {
            statusLabel.setText("Podaj numer portu!");
            return;
        }

        try {
            int port = Integer.parseInt(portText);
            connectButton.setDisable(true);
            backButton.setDisable(true);

            boolean isHosting = ip.isEmpty();

            new Thread(() -> {
                NetworkManager nm = NetworkManager.getInstance();
                try {
                    boolean success;
                    if (isHosting) {
                        Platform.runLater(() -> statusLabel.setText("Uruchamianie serwera (Host)..."));
                        success = nm.startHost(port);
                    } else {
                        Platform.runLater(() -> statusLabel.setText("Łączenie z " + ip + "..."));
                        success = nm.connect(ip, port);
                    }

                    if (!success) {
                        Platform.runLater(() -> {
                            statusLabel.setText("Błąd: Nie udało się " + (isHosting ? "postawić serwera" : "połączyć"));
                            connectButton.setDisable(false);
                            backButton.setDisable(false);
                        });
                    }
                } catch (Exception e) {
                    Platform.runLater(() -> {
                        statusLabel.setText("Błąd krytyczny połączenia.");
                        connectButton.setDisable(false);
                        backButton.setDisable(false);
                    });
                }
            }).start();
        } catch (NumberFormatException e) {
            statusLabel.setText("Port musi być liczbą!");
        }
    }

    /**
     * Rozłącza aktywne połączenie i wraca do głównego menu.
     * * @author Jakub Bąk
     */
    @FXML
    private void onBack() {
        NetworkManager.getInstance().disconnect();
        SceneUtils.changeScene("menu.fxml");
    }

    /**
     * Reaguje na pomyślne połączenie drugiego gracza, przełączając scenę na grę.
     * * @author Jakub Bąk
     */
    @Override
    public void onPlayerConnected() {
        Platform.runLater(() -> {
            System.out.println("Połączono pomyślnie! Przechodzenie do gry...");
            SceneUtils.changeScene("game.fxml");
        });
    }

    /**
     * Reaguje na utratę połączenia, informując użytkownika i odblokowując interfejs.
     * * @author Jakub Bąk
     */
    @Override
    public void onConnectionLost() {
        Platform.runLater(() -> {
            statusLabel.setText("Utracono połączenie");
            connectButton.setDisable(false);
            backButton.setDisable(false);
        });
    }

    @Override public void onGameStateReceived(GameState state) {}
    @Override public void onActionReceived(String action) {}
    @Override public void onHandshakeReceived(String name) {}
}