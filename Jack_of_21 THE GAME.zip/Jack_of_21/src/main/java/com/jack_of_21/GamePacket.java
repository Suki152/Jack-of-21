package com.jack_of_21;

import java.io.Serializable;

/**
 * Klasa reprezentująca pakiet danych przesyłany przez sieć.
 * Służy do komunikacji między klientem a hostem, przenosząc informacje
 * o stanie gry, wykonywanych akcjach lub identyfikacji graczy.
 * Implementuje interfejs Serializable, aby umożliwić przesyłanie obiektów strumieniem.
 *
 * @author Jakub Bąk
 * @version 1.0
 */
public class GamePacket implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * Typ wyliczeniowy określający rodzaj przesyłanego pakietu.
     * Definiuje sposób interpretacji zawartości pakietu przez odbiorcę.
     *
     * @author Jakub Bąk
     */
    public enum PacketType {
        /** Służy do wstępnej wymiany imion graczy przy nawiązywaniu połączenia. */
        HANDSHAKE,

        /** Zawiera pełny obiekt stanu gry (GameState), wysyłany zazwyczaj przez Hosta. */
        STATE,

        /** Zawiera krótką informację o akcji (np. HIT, STAND), wysyłaną przez Klienta. */
        ACTION
    }

    /** Typ tego pakietu. */
    private PacketType type;

    /** Obiekt stanu gry, obecny tylko gdy typ pakietu to STATE. */
    private GameState state;

    /**
     * Wiadomość tekstowa przenosząca dodatkowe informacje.
     * W przypadku HANDSHAKE jest to nick gracza, w przypadku ACTION jest to kod akcji.
     */
    private String message;

    /**
     * Konstruktor dla pakietów typu HANDSHAKE oraz ACTION.
     *
     * @param type    Typ pakietu (nie może być STATE w tym konstruktorze).
     * @param message Treść wiadomości (np. imię gracza lub komenda "HIT").
     */
    public GamePacket(PacketType type, String message) {
        this.type = type;
        this.message = message;
    }

    /**
     * Konstruktor dla pakietów typu STATE.
     * Automatycznie ustawia typ pakietu na STATE.
     *
     * @param state Obiekt stanu gry do przesłania.
     */
    public GamePacket(GameState state) {
        this.type = PacketType.STATE;
        this.state = state;
    }

    /**
     * Pobiera typ pakietu.
     * @return Typ wyliczeniowy PacketType.
     */
    public PacketType getType() { return type; }

    /**
     * Pobiera obiekt stanu gry.
     * @return Obiekt GameState lub null, jeśli pakiet nie jest typu STATE.
     */
    public GameState getState() { return state; }

    /**
     * Pobiera wiadomość tekstową powiązaną z pakietem.
     * @return String zawierający treść wiadomości lub kod akcji.
     */
    public String getMessage() { return message; }
}