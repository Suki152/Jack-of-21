package com.jack_of_21;

import java.io.*;
import java.util.*;

/**
 * Klasa zarządzająca profilami graczy (Data Persistence).
 * Odpowiada za wczytywanie, zapisywanie, tworzenie i usuwanie profili
 * z pliku tekstowego (profiles.txt). Przechowuje również informację
 * o aktualnie zalogowanym profilu.
 *
 * @author Jakub Bąk
 * @author Kacper Chojnacki
 */
public class ProfileManager {
    /** Ścieżka do pliku przechowującego dane profili. */
    private static final String FILE_PATH = "profiles.txt";
    /** Referencja do aktualnie wybranego (zalogowanego) profilu. */
    private static PlayerProfile currentProfile;

    /**
     * Pobiera profil o podanej nazwie, jeśli istnieje.
     * Wczytuje dane z pliku przy każdym wywołaniu, aby zapewnić aktualność.
     *
     * @param name Nazwa szukanego profilu.
     * @return Obiekt PlayerProfile lub null, jeśli nie znaleziono.
     */
    public static PlayerProfile getProfile(String name) {
        Map<String, PlayerProfile> profiles = loadProfiles();
        return profiles.get(name);
    }

    /**
     * Tworzy nowy profil gracza, zapisuje go do pliku i zwraca jego instancję.
     *
     * @param name Nazwa dla nowego profilu.
     * @return Utworzony obiekt PlayerProfile.
     */
    public static PlayerProfile createProfile(String name) {
        Map<String, PlayerProfile> profiles = loadProfiles();
        PlayerProfile newProfile = new PlayerProfile(name, 0, 0);
        profiles.put(name, newProfile);
        saveProfiles(profiles);
        return newProfile;
    }

    /**
     * Usuwa profil o podanej nazwie z systemu i aktualizuje plik danych.
     *
     * @param name Nazwa profilu do usunięcia.
     */
    public static void deleteProfile(String name) {
        Map<String, PlayerProfile> profiles = loadProfiles();
        if (profiles.containsKey(name)) {
            profiles.remove(name);
            saveProfiles(profiles);
        }
    }

    /**
     * Zapisuje stan aktualnie zalogowanego profilu do pliku.
     * Wywoływana po zakończeniu gry, aby zaktualizować statystyki.
     */
    public static void saveCurrentProfile() {
        if (currentProfile == null) return;

        Map<String, PlayerProfile> profiles = loadProfiles();
        profiles.put(currentProfile.getName(), currentProfile);
        saveProfiles(profiles);
    }

    /**
     * Ustawia profil jako aktualnie zalogowany w sesji aplikacji.
     * @param profile Profil gracza.
     */
    public static void setCurrentProfile(PlayerProfile profile) {
        currentProfile = profile;
    }

    /**
     * Pobiera aktualnie zalogowany profil.
     * @return Obiekt PlayerProfile lub null, jeśli nikt nie jest zalogowany.
     */
    public static PlayerProfile getCurrentProfile() {
        return currentProfile;
    }

    /**
     * Pobiera listę wszystkich dostępnych profili.
     * Używane do wyświetlania listy w oknie logowania.
     *
     * @return Lista wszystkich obiektów PlayerProfile.
     */
    public static List<PlayerProfile> getAllProfiles() {
        return new ArrayList<>(loadProfiles().values());
    }

    /**
     * Wczytuje wszystkie profile z pliku tekstowego do mapy.
     * Format pliku: nazwa;rozegrane;wygrane
     *
     * @return Mapa (Nazwa -> Profil) zawierająca wczytane dane.
     */
    private static Map<String, PlayerProfile> loadProfiles() {
        Map<String, PlayerProfile> map = new HashMap<>();

        File file = new File(FILE_PATH);
        if (!file.exists()) return map;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length == 3) {
                    String name = parts[0];
                    int played = Integer.parseInt(parts[1]);
                    int won = Integer.parseInt(parts[2]);
                    map.put(name, new PlayerProfile(name, played, won));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return map;
    }

    /**
     * Zapisuje podaną mapę profili do pliku tekstowego.
     * Nadpisuje istniejącą zawartość pliku.
     *
     * @param map Mapa profili do zapisania.
     */
    private static void saveProfiles(Map<String, PlayerProfile> map) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (PlayerProfile p : map.values()) {
                bw.write(p.toString());
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}