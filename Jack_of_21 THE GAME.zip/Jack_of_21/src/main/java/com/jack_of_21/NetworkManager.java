package com.jack_of_21;

import java.io.*;
import java.net.*;
import java.util.Enumeration;
import java.util.concurrent.*;

/**
 * Singleton zarządzający połączeniami sieciowymi w grze.
 * Obsługuje tryb Hosta (serwera) oraz Klienta.
 * Odpowiada za nawiązywanie połączeń (TCP), wysyłanie i odbieranie pakietów danych
 * w osobnych wątkach, aby nie blokować interfejsu użytkownika.
 *
 * @author Jakub Bąk
 * @author Kacper Chojnacki
 */
public class NetworkManager {
    private static NetworkManager instance;

    private Socket socket;
    private ServerSocket serverSocket;
    private ObjectOutputStream output;
    private ObjectInputStream input;

    private volatile boolean isHost = false;
    private volatile boolean connected = false;

    private ExecutorService networkExecutor;
    private PacketListener listener;

    /**
     * Interfejs nasłuchujący zdarzeń sieciowych.
     * Implementowany przez kontrolery widoków, które chcą reagować na pakiety.
     */
    public interface PacketListener {
        /** Odbiór stanu gry (dla klienta). */
        void onGameStateReceived(GameState state);
        /** Odbiór akcji (np. HIT, STAND). */
        void onActionReceived(String action);
        /** Odbiór powitania z imieniem gracza. */
        void onHandshakeReceived(String name);
        /** Utrata połączenia. */
        void onConnectionLost();
        /** Pomyślne nawiązanie połączenia. */
        void onPlayerConnected();
    }

    /**
     * Pobiera instancję singletona NetworkManager.
     * @return Jedyna instancja NetworkManager.
     */
    public static NetworkManager getInstance() {
        if (instance == null) {
            instance = new NetworkManager();
        }
        return instance;
    }

    private NetworkManager() {}

    /**
     * Ustawia listenera, który będzie otrzymywał powiadomienia o pakietach.
     * @param listener Obiekt implementujący interfejs PacketListener.
     */
    public void setPacketListener(PacketListener listener) {
        this.listener = listener;
    }

    /**
     * Inicjalizuje pulę wątków dla operacji sieciowych.
     */
    private void initExecutor() {
        if (networkExecutor == null || networkExecutor.isShutdown() || networkExecutor.isTerminated()) {
            networkExecutor = Executors.newFixedThreadPool(2);
        }
    }

    // --- LOGIKA POŁĄCZEŃ ---

    /**
     * Uruchamia serwer (Hosta) na podanym porcie i nasłuchuje na połączenie.
     * Operacja odbywa się w tle.
     *
     * @param port Numer portu do nasłuchu.
     * @return true, jeśli serwer wystartował pomyślnie (nie oznacza to jeszcze podłączenia gracza).
     */
    public boolean startHost(int port) {
        disconnect();
        initExecutor();

        try {

            isHost = true;
            serverSocket = new ServerSocket(port);

            networkExecutor.submit(() -> {
                try {
                    System.out.println("Host: Oczekiwanie na gracza na porcie " + port);
                    socket = serverSocket.accept();
                    System.out.println("Host: Gracz połączony z adresu: " + socket.getInetAddress());

                    setupStreams();
                    connected = true;

                    if (listener != null) {
                        listener.onPlayerConnected();
                    }

                    startReceiving();

                } catch (IOException e) {
                    if (!serverSocket.isClosed()) {
                        System.err.println("Błąd serwera: " + e.getMessage());
                    }
                }
            });

            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Łączy się jako Klient z podanym adresem IP i portem.
     *
     * @param ip Adres IP serwera (Hosta).
     * @param port Numer portu.
     * @return true, jeśli udało się nawiązać połączenie.
     */
    public boolean connect(String ip, int port) {
        disconnect();
        initExecutor();

        try {
            socket = new Socket();
            socket.connect(new InetSocketAddress(ip, port), 5000); // Timeout 5s

            isHost = false;

            setupStreams();
            connected = true;

            if (listener != null) {
                listener.onPlayerConnected();
            }

            startReceiving();
            return true;

        } catch (IOException e) {
            System.err.println("Błąd łączenia: " + e.getMessage());
            return false;
        }
    }

    /**
     * Inicjalizuje strumienie wejścia/wyjścia dla aktywnego gniazda.
     * Wymagane flush() dla ObjectOutputStream zaraz po utworzeniu.
     */
    private void setupStreams() throws IOException {
        output = new ObjectOutputStream(socket.getOutputStream());
        output.flush();
        input = new ObjectInputStream(socket.getInputStream());
    }

    // --- UTILITIES ---

    /**
     * Pomaga znaleźć prawdziwe IP w sieci lokalnej (np. 192.168.x.x),
     * ignorując interfejsy loopback (127.0.0.1).
     *
     * @return String z adresem IP lub komunikat błędu.
     */
    public String getLocalIpAddress() {
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces.hasMoreElements()) {
                NetworkInterface iface = interfaces.nextElement();
                if (iface.isLoopback() || !iface.isUp()) continue;

                Enumeration<InetAddress> addresses = iface.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    InetAddress addr = addresses.nextElement();
                    // Szukamy adresu IPv4
                    if (addr instanceof Inet4Address) {
                        return addr.getHostAddress();
                    }
                }
            }
            return "Nieznane (sprawdź ipconfig)";
        } catch (SocketException e) {
            return "Błąd";
        }
    }

    // --- WYSYŁANIE I ODBIERANIE ---

    /**
     * Wysyła obiekt stanu gry (GameState) do drugiego gracza.
     * Zwykle używane przez Hosta do synchronizacji Klienta.
     *
     * @param state Aktualny stan gry.
     */
    public void sendGameState(GameState state) {
        if (!connected || output == null) return;
        networkExecutor.submit(() -> {
            try {
                output.writeObject(new GamePacket(state));
                output.reset(); // Ważne dla serializacji obiektów zmieniających się w czasie
                output.flush();
            } catch (IOException e) {
                System.err.println("Błąd wysyłania stanu: " + e.getMessage());
                notifyConnectionLost();
            }
        });
    }

    /**
     * Wysyła komendę akcji (tekst) do drugiego gracza.
     *
     * @param action Kod akcji (np. "HIT", "STAND").
     */
    public void sendAction(String action) {
        if (!connected || output == null) return;
        networkExecutor.submit(() -> {
            try {
                output.writeObject(new GamePacket(GamePacket.PacketType.ACTION, action));
                output.flush();
            } catch (IOException e) {
                System.err.println("Błąd wysyłania akcji: " + e.getMessage());
                notifyConnectionLost();
            }
        });
    }

    /**
     * Wysyła pakiet handshake z imieniem gracza.
     *
     * @param name Nazwa/Nick gracza.
     */
    public void sendHandshake(String name) {
        if (!connected || output == null) return;
        networkExecutor.submit(() -> {
            try {
                output.writeObject(new GamePacket(GamePacket.PacketType.HANDSHAKE, name));
                output.flush();
            } catch (IOException e) {
                System.err.println("Błąd wysyłania handshake: " + e.getMessage());
            }
        });
    }

    /**
     * Uruchamia pętlę nasłuchującą na pakiety przychodzące w osobnym wątku.
     * Po odebraniu pakietu przekazuje go do Listenera na wątku JavaFX (Platform.runLater).
     */
    private void startReceiving() {
        networkExecutor.submit(() -> {
            while (connected && !Thread.currentThread().isInterrupted()) {
                try {
                    GamePacket packet = (GamePacket) input.readObject();
                    if (listener != null) {
                        javafx.application.Platform.runLater(() -> {
                            switch (packet.getType()) {
                                case HANDSHAKE:
                                    listener.onHandshakeReceived(packet.getMessage());
                                    break;
                                case ACTION:
                                    listener.onActionReceived(packet.getMessage());
                                    break;
                                case STATE:
                                    if (packet.getState() != null) {
                                        listener.onGameStateReceived(packet.getState());
                                    }
                                    break;
                            }
                        });
                    }
                } catch (IOException | ClassNotFoundException e) {
                    if (connected) {
                        System.err.println("Receive error: " + e.getMessage());
                        notifyConnectionLost();
                    }
                    break;
                }
            }
        });
    }

    /**
     * Zgłasza utratę połączenia listenerowi (na wątku JavaFX).
     */
    private void notifyConnectionLost() {
        if (!connected) return;
        connected = false;
        if (listener != null) {
            javafx.application.Platform.runLater(listener::onConnectionLost);
        }
    }


    public boolean isConnected() { return connected; }
    public boolean isHost() { return isHost; }

    /**
     * Zamyka połączenie, gniazda i pulę wątków.
     * Sprząta zasoby sieciowe.
     */
    public void disconnect() {
        connected = false;
        try { if (socket != null) socket.close(); } catch (IOException e) {}
        try { if (serverSocket != null) serverSocket.close(); } catch (IOException e) {}
        socket = null;
        serverSocket = null;
        output = null;
        input = null;
        if (networkExecutor != null && !networkExecutor.isShutdown()) {
            networkExecutor.shutdownNow();
        }
        networkExecutor = null;
    }
}